# AI Sentinel — Zero-Trust AI Security Guardian & Gateway

[![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)](https://ai.studio/build)
[![Security](https://img.shields.io/badge/Security-Zero--Trust%20DLP-red)](https://github.com)
[![Model](https://img.shields.io/badge/AI%20Model-Gemini%203.7%20Flash-blue)](https://deepmind.google/technologies/gemini/)
[![Framework](https://img.shields.io/badge/Architecture-Streamlit%20UI%20%2B%20TypeScript%20Fullstack-orange)](https://streamlit.io)

> **AI Sentinel** is an enterprise-grade AI security gateway, threat simulator, and real-time Data Loss Prevention (DLP) reverse-proxy that intercepts, detects, sanitizes, and audits sensitive data before it reaches external Large Language Models (LLMs).

---

## 📌 Problem Statement

As organizations accelerate their adoption of generative AI models, employees and automated agents routinely transmit sensitive operational data in model prompts. Unchecked AI egress introduces critical enterprise risks:

1. **Unintentional PII & Statutory ID Leaks**: Direct exposure of Customer Identifiers, Indian PAN tax cards, Aadhaar UIDs, and Social Security Numbers into cloud model logs.
2. **Payment Card & Financial Exposure**: Violations of PCI-DSS regulations through the transmission of credit card PANs, CVVs, and bank account credentials.
3. **Infrastructure Credential Exposure**: Accidental leakage of cloud API keys, secret tokens, and connection strings into prompt histories.
4. **Healthcare Data Privacy Breaches**: Unsanitized transmission of Protected Health Information (PHI) violating HIPAA and GDPR mandates.
5. **Adversarial Prompt Injections & Jailbreaks**: Malicious payloads designed to bypass system guardrails, subvert policies, and exfiltrate internal configuration data.

---

## 🛡️ Solution Overview

**AI Sentinel** implements a **Zero-Trust AI Security Reverse-Proxy** operating between enterprise users/microservices and external AI models (like Google Gemini). 

Instead of allowing raw prompts to egress directly, AI Sentinel enforces an automated **6-Stage Security Pipeline**:
1. **Raw Payload Ingestion**: Intercepts outgoing prompt payloads.
2. **Deep Entity Scanning**: Runs multi-category regular expressions and heuristic heuristics across 8+ sensitive data vectors.
3. **Threat Classification**: Categorizes risks across PII, Government IDs, Financial Records, API Credentials, Healthcare Data, and Prompt Injection Jailbreaks.
4. **Quantitative Risk Scoring**: Computes a weighted risk index (0–100) reflecting compound threat density and severity.
5. **Intelligent Policy Decision**: Evaluates organizational DLP rules to enforce **ALLOW**, **MASK**, **REDACT**, or **BLOCK** actions.
6. **Sanitization & Model Dispatch**: Dispatches sanitized/redacted prompts to the Gemini model API, returning safe responses while recording tamper-evident audit logs.

---

## ✨ Key Features

- **🔥 AI Threat Simulator (Phase 3)**:
  - Interactive red-team laboratory featuring 6 pre-configured adversarial attack scenarios (Customer PII, Indian PAN/Aadhaar IDs, PCI Card Leaks, Cloud API Keys, Medical PHI, and Prompt Injection Jailbreaks).
  - Custom payload editor to test arbitrary adversarial strings against the zero-trust pipeline.
  - Step-by-step 6-stage pipeline visualizer showing real-time token detection, weighted risk calculations, and forensic policy justifications.

- **✨ Live AI Playground (Gemini Gateway)**:
  - Interactive prompt interface with dual pre/post-sanitization comparison views.
  - Live model execution using Google Gemini 3.7 Flash with server-side API key isolation.
  - Seamless fallback simulation mode for zero-setup demonstrations when API keys are unconfigured.

- **🔍 PII & Sensitive Entity Scanner**:
  - Live text and document analyzer detecting 8+ sensitive entity categories.
  - Interactive redact/mask controls with token-level highlighting.
  - Formatted entity extraction tables and security metric scorecards.

- **📊 Security Telemetry Dashboard**:
  - Real-time visualizations of threat distribution, blocked vs. sanitized requests, and risk severity trends.
  - Latency monitoring and compliance category coverage metrics.

- **📜 Tamper-Evident Audit Logs**:
  - Centralized security audit records containing SHA-256 integrity hashes, client IP addresses, risk scores, and policy actions.
  - Search, filter by severity/action, and single-click CSV export for compliance reporting (SOC2, ISO 27001, HIPAA).

- **⚙️ Configurable Intelligent Policy Engine**:
  - Granular control over detection rules for PII, Financial data, Government IDs, Healthcare PHI, and Prompt Injections.
  - Adjustable risk score auto-block threshold slider (40–100).
  - Streamlit-native UI theme matching official Streamlit design standards (`#ff4b4b` accents, clean typography, modular sidebars).

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend UI** | React 19, TypeScript, Tailwind CSS, Lucide Icons, Streamlit-Authentic UI System |
| **Backend & Proxy** | Node.js, Express, TypeScript (`tsx`), Vite Server Middleware |
| **AI & LLM Integration** | Google GenAI SDK (`@google/genai`), Gemini 3.7 Flash Model |
| **Data Loss Prevention** | Multi-vector Regex Matchers, Shannon Entropy Heuristics, Luhn Checksum Algorithm |
| **Build & Tooling** | Vite 6, esbuild (CommonJS server bundle), ESLint, TypeScript Compiler |

---

## 🔄 System Workflow

```
[ User / Microservice Client ]
             │
             ▼  (Raw Prompt Payload)
┌─────────────────────────────────────────────────────────┐
│              AI SENTINEL SECURITY GATEWAY               │
│                                                         │
│  [ Stage 1: Ingestion & Parsing ]                       │
│        │                                                │
│  [ Stage 2: Deep Entity & Pattern Scanner ]             │
│        │   ├─ PII (Names, Emails, Phones)               │
│        │   ├─ Govt IDs (Indian PAN, Aadhaar)            │
│        │   ├─ Financial (Credit Cards, IBANs)           │
│        │   ├─ Secrets (API Keys, JWTs, Passwords)       │
│        │   └─ Prompt Injections (DAN, System Overrides) │
│        │                                                │
│  [ Stage 3: Threat Classification & Taxonomy ]          │
│        │                                                │
│  [ Stage 4: Weighted Risk Scoring (0-100) ]             │
│        │                                                │
│  [ Stage 5: Intelligent Policy Engine ]                 │
│        │   ├─ Decision: BLOCK / REDACT / MASK / ALLOW   │
│        │   └─ Risk Threshold Enforcement                │
│        │                                                │
│  [ Stage 6: Sanitization & Audit Engine ]               │
│        │   ├─ Create SHA-256 Audit Log Record           │
│        │   └─ Produce Neutralized Prompt                │
└──────────────────────────┬──────────────────────────────┘
                           │
             ┌─────────────┴─────────────┐
             ▼                           ▼
      [ Policy: BLOCK ]          [ Policy: SANITIZE/ALLOW ]
             │                           │
   Return Security Alert                 ▼
   (Model Call Aborted)        [ Google Gemini 3.7 Flash ]
                                         │
                                         ▼ (Safe Model Response)
                               [ Client Delivery ]
```

---

## 🚀 How to Install and Run

### Prerequisites
- Node.js (v18.0.0 or higher)
- npm (v9.0.0 or higher)

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/ai-sentinel.git
cd ai-sentinel
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment Variables (Optional for Live Gemini Mode)
Create a `.env` file in the root directory (based on `.env.example`):
```env
GEMINI_API_KEY="your-gemini-api-key-here"
```

*(Note: AI Sentinel runs out-of-the-box in simulation fallback mode if no API key is provided, ensuring seamless evaluation).*

### 4. Run the Development Server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000`.

### 5. Production Build
```bash
npm run build
npm start
```

---

## 🔑 How to Configure Gemini API

1. Obtain a free Gemini API key from [Google AI Studio](https://aistudio.google.com/).
2. In your local or cloud environment, set the environment variable:
   ```bash
   export GEMINI_API_KEY="your_actual_api_key"
   ```
   Or add it to your `.env` file:
   ```env
   GEMINI_API_KEY=AIzaSy...
   ```
3. When running inside **Google AI Studio Build**, the API key is automatically injected securely via the Secrets panel.
4. Verify the active status by visiting the **AI Playground** page in AI Sentinel; the system will display `● LIVE GEMINI API CONNECTED`.

---

## 👥 Team & Project Information

- **Project Name**: Remix AI Sentinel
- **Application Type**: AI Security Gateway & Zero-Trust Threat Simulator
- **Platform**: Google AI Studio & Cloud Run
- **Design Philosophy**: Streamlit-authentic visual architecture paired with high-performance zero-trust security engineering.

---

## 🔮 Future Scope

1. **Active Real-Time Egress Streaming**: Token-by-token streaming inspection with sub-millisecond AST sanitization.
2. **Context-Aware Semantic Embeddings**: Vector similarity scoring against enterprise knowledge bases to prevent proprietary IP leakage.
3. **Multi-Model Routing & Failover**: Dynamic policy-driven routing across Gemini Pro, Flash, and private VPC-hosted models.
4. **Automated SIEM / Webhook Integration**: Native webhook forwarders for Splunk, Datadog, and AWS CloudWatch.
5. **Zero-Knowledge Encryption Vault**: Bi-directional token deanonymization enabling round-trip response reconstitution without exposing plaintext to model servers.
