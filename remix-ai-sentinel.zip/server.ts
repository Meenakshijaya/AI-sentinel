import express, { Request, Response } from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Check Gemini API Configuration Status
  app.get('/api/gemini/status', (req: Request, res: Response) => {
    const isConfigured = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
    res.json({
      isConfigured,
      model: 'gemini-3.7-flash',
      mode: isConfigured ? 'LIVE_GEMINI' : 'SIMULATION_FALLBACK',
      message: isConfigured 
        ? 'Gemini API Key is active. Live inference enabled.'
        : 'Gemini API Key not detected in environment. Operating in zero-setup simulation fallback mode.'
    });
  });

  // Secure Gemini Generation Endpoint (Server-Side Proxy)
  app.post('/api/gemini/generate', async (req: Request, res: Response) => {
    const startTime = Date.now();
    const { sanitizedPrompt, originalPromptLength, detectedEntitiesCount } = req.body;

    if (!sanitizedPrompt || typeof sanitizedPrompt !== 'string' || sanitizedPrompt.trim().length === 0) {
      return res.status(400).json({
        error: 'A non-empty sanitizedPrompt string is required.'
      });
    }

    const apiKey = process.env.GEMINI_API_KEY?.trim();

    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
        });

        const response = await ai.models.generateContent({
          model: 'gemini-3.7-flash',
          contents: sanitizedPrompt,
          config: {
            systemInstruction: 'You are an intelligent, secure AI model assistant operating behind the AI Sentinel enterprise security gateway. The user prompt you receive has had sensitive personal identifiers, credentials, and PII masked/sanitized (e.g. [REDACTED_EMAIL], [REDACTED_PHONE], [REDACTED_PAN], [REDACTED_NAME], [REDACTED_API_KEY]). Generate a helpful, professional, concise, and context-appropriate response directly addressing the user\'s sanitized query.'
          }
        });

        const latencyMs = Date.now() - startTime;
        const responseText = response.text || 'Response generated successfully.';

        return res.json({
          text: responseText,
          model: 'gemini-3.7-flash',
          mode: 'live',
          latencyMs,
          tokenCount: Math.round((sanitizedPrompt.length + responseText.length) / 4),
          timestamp: new Date().toISOString()
        });
      } catch (error: any) {
        console.error('Gemini API live request failed:', error?.message || error);
        // Fall through to smart simulation with notice
      }
    }

    // Smart Simulation Fallback Mode (For zero-config hackathon preview or missing key)
    const latencyMs = Math.max(180, Date.now() - startTime + 250);
    const lowerPrompt = sanitizedPrompt.toLowerCase();
    let simulatedText = '';

    if (lowerPrompt.includes('priya') || lowerPrompt.includes('customer') || lowerPrompt.includes('email is [redacted')) {
      simulatedText = `Dear Customer,\n\nThank you for contacting our support team. We have received your inquiry and are actively reviewing the details. Our team will follow up via your registered contact details within 1 business day.\n\nIf you have any urgent queries in the meantime, please feel free to reply to this ticket.\n\nBest regards,\nCustomer Success & Support Team`;
    } else if (lowerPrompt.includes('api key') || lowerPrompt.includes('secret_api_key') || lowerPrompt.includes('configure the service')) {
      simulatedText = `### Service Configuration Guide (Zero-Trust Best Practice)\n\nTo securely configure the service without leaking credentials into prompt history:\n\n1. **Environment Variables:** Set your key in your secure runtime environment (e.g. \`export SERVICE_KEY="your-token"\`).\n2. **Secret Management:** Utilize Google Secret Manager, HashiCorp Vault, or AWS Secrets Manager.\n3. **Gateway Protection:** Always route LLM requests through AI Sentinel to mask tokens before cloud egress.\n4. **Client Initialization:** In code, load credentials via \`process.env.SERVICE_KEY\` rather than hardcoded strings.`;
    } else if (lowerPrompt.includes('rajesh') || lowerPrompt.includes('pan') || lowerPrompt.includes('aadhaar') || lowerPrompt.includes('employment verification')) {
      simulatedText = `### EMPLOYMENT & IDENTITY VERIFICATION CERTIFICATE\n\n**To Whom It May Concern,**\n\nThis is to certify that the specified employee is currently employed as a full-time professional in good standing with our organization.\n\n- **Employee Status:** Active / Full-Time\n- **Designation:** Senior Software Engineer\n- **Identity Documents:** Verified against statutory records (PAN & Aadhaar UIDAI on secure file)\n- **Purpose:** Loan & Housing Finance Processing\n\nThis certificate is issued at the request of the employee without liability to the issuing authority.\n\n*Authorized Signatory*\n**Human Resources & Compliance Department**`;
    } else if (lowerPrompt.includes('zero-trust') || lowerPrompt.includes('reverse-proxy') || lowerPrompt.includes('firewall')) {
      simulatedText = `### Zero-Trust AI Reverse-Proxy vs. Client-Side Sanitation\n\n1. **Centralized Policy Enforcement:** A reverse-proxy gateway (like AI Sentinel) enforces DLP, rate limits, and compliance across all company microservices without trusting end-client implementations.\n2. **Zero Client Tampering:** Client-side sanitizers can be disabled or bypassed by modified web scripts or curl requests; an egress proxy inspects every wire payload.\n3. **Compliance Audit Trail:** Reverse proxies generate immutable SOC2 / HIPAA / GDPR audit logs of all sanitized and blocked requests centrally.`;
    } else {
      simulatedText = `Thank you for your prompt. I have processed your request safely through AI Sentinel.\n\nBased on your query: "${sanitizedPrompt.length > 80 ? sanitizedPrompt.substring(0, 80) + '...' : sanitizedPrompt}"\n\nAll personal identity markers and credentials in this session were neutralized before processing. Let me know if you would like me to elaborate or provide further assistance!`;
    }

    return res.json({
      text: simulatedText,
      model: 'gemini-3.7-flash (Simulated Mode)',
      mode: 'simulation',
      latencyMs,
      tokenCount: Math.round((sanitizedPrompt.length + simulatedText.length) / 4),
      notice: 'Operating in Demo/Simulation mode. To enable live Gemini API inference, provide GEMINI_API_KEY in your environment/secrets settings.',
      timestamp: new Date().toISOString()
    });
  });

  // Vite Middleware in Development / Static Files in Production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Sentinel Gateway server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
