import { PIIEntity, ScanResult, SentinelSettings, GateDecision, ThreatClassification, ThreatCategory } from '../types';

export function runPIIScan(text: string, settings: SentinelSettings): ScanResult {
  const startTime = performance.now();
  const entities: PIIEntity[] = [];

  if (!text || text.trim().length === 0) {
    const emptyClassification: ThreatClassification = {
      primaryCategory: 'SAFE_NORMAL',
      categoryLabel: 'Safe / Normal Payload',
      detectedThreats: [],
      severity: 'LOW',
      riskScore: 0,
      hasPromptInjection: false,
      explanation: 'No inputs detected.'
    };

    return {
      originalText: text,
      redactedText: '',
      detectedEntities: [],
      riskScore: 0,
      threatClassification: emptyClassification,
      scanDurationMs: 0.1,
      timestamp: new Date().toLocaleTimeString(),
      decision: {
        action: 'ALLOW',
        reason: 'Empty payload — no security risk detected.',
        blockedCategories: [],
        maskedCategories: [],
        whyExplanation: {
          threat: 'None',
          risk: '0/100 — SAFE',
          detected: ['No sensitive tokens'],
          policy: 'ALLOW',
          reason: 'Payload contains no sensitive information.'
        }
      }
    };
  }

  // 1. SSN Scanner
  if (settings.detectors.ssn) {
    const ssnRegex = /\b(\d{3}-\d{2}-\d{4})\b/g;
    let match;
    while ((match = ssnRegex.exec(text)) !== null) {
      entities.push({
        id: `ssn-${match.index}`,
        type: 'SSN',
        value: match[1],
        confidence: 0.99,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        severity: 'critical',
        suggestion: 'Social Security Number must never be transmitted to external LLMs.'
      });
    }
  }

  // 2. Indian PAN Card Scanner ([A-Z]{5}[0-9]{4}[A-Z]{1})
  if (settings.detectors.pan) {
    const panRegex = /\b([A-Z]{5}[0-9]{4}[A-Z]{1})\b/g;
    let match;
    while ((match = panRegex.exec(text)) !== null) {
      entities.push({
        id: `pan-${match.index}`,
        type: 'PAN',
        value: match[1],
        confidence: 0.98,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        severity: 'critical',
        suggestion: 'Indian Permanent Account Number (PAN) tax identifier.'
      });
    }
  }

  // 3. Indian Aadhaar Card Scanner (12 digits with optional spaces or hyphens)
  if (settings.detectors.aadhaar) {
    const aadhaarRegex = /\b([2-9]\d{3}[\s-]?\d{4}[\s-]?\d{4})\b/g;
    let match;
    while ((match = aadhaarRegex.exec(text)) !== null) {
      const isAlreadyCovered = entities.some(e => match!.index >= e.startIndex && match!.index < e.endIndex);
      if (!isAlreadyCovered) {
        entities.push({
          id: `aadhaar-${match.index}`,
          type: 'AADHAAR',
          value: match[1],
          confidence: 0.96,
          startIndex: match.index,
          endIndex: match.index + match[0].length,
          severity: 'critical',
          suggestion: 'Indian Aadhaar 12-digit Unique Identification Number (UIDAI).'
        });
      }
    }
  }

  // 4. Credit / Debit Card Scanner
  if (settings.detectors.creditCard) {
    const ccRegex = /\b(?:\d{4}[ -]?){3}\d{4}\b/g;
    let match;
    while ((match = ccRegex.exec(text)) !== null) {
      const isAlreadyCovered = entities.some(e => match!.index >= e.startIndex && match!.index < e.endIndex);
      if (!isAlreadyCovered) {
        entities.push({
          id: `cc-${match.index}`,
          type: 'CREDIT_CARD',
          value: match[0],
          confidence: 0.98,
          startIndex: match.index,
          endIndex: match.index + match[0].length,
          severity: 'critical',
          suggestion: 'Payment card details violate PCI-DSS compliance requirements.'
        });
      }
    }

    // Bank Account & Routing Numbers
    const bankRegex = /\b(?:Account|Acc\.?|Routing|Wire|IBAN)[:\s#]*(\d{9,16})\b/gi;
    while ((match = bankRegex.exec(text)) !== null) {
      const isAlreadyCovered = entities.some(e => match!.index >= e.startIndex && match!.index < e.endIndex);
      if (!isAlreadyCovered) {
        entities.push({
          id: `bank-${match.index}`,
          type: 'BANK_ACCOUNT',
          value: match[1],
          confidence: 0.94,
          startIndex: match.index,
          endIndex: match.index + match[0].length,
          severity: 'high',
          suggestion: 'Direct bank account / routing transit credential.'
        });
      }
    }
  }

  // 5. API Key & Token & Cloud Secret Scanner
  if (settings.detectors.apiKeys) {
    const apiKeyRegex = /\b(SECRET_API_KEY_[a-zA-Z0-9_-]+|sk-(?:proj-)?[a-zA-Z0-9_-]{16,}|AKIA[0-9A-Z]{16}|ghp_[a-zA-Z0-9]{36}|AIza[0-9A-Za-z-_]{35}|bearer\s+[a-zA-Z0-9_.-]{20,})\b/gi;
    let match;
    while ((match = apiKeyRegex.exec(text)) !== null) {
      entities.push({
        id: `key-${match.index}`,
        type: 'API_KEY',
        value: match[0],
        confidence: 0.99,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        severity: 'critical',
        suggestion: 'Exposed developer secret token or API key.'
      });
    }
  }

  // 6. Email & Phone Scanner (supports US, Indian & International formats)
  if (settings.detectors.emailPhone) {
    const emailRegex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g;
    let match;
    while ((match = emailRegex.exec(text)) !== null) {
      entities.push({
        id: `email-${match.index}`,
        type: 'EMAIL',
        value: match[0],
        confidence: 0.97,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        severity: 'medium',
        suggestion: 'Personal identifiable email address.'
      });
    }

    // Phone numbers: US +1, (xxx) xxx-xxxx, 10-digit Indian 9876543210, +91-9876543210, etc.
    const phoneRegex = /(?:\+?91[\-\s]?)?[6-9]\d{9}\b|\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
    while ((match = phoneRegex.exec(text)) !== null) {
      const val = match[0];
      const isAlreadyCovered = entities.some(e => match!.index >= e.startIndex && match!.index < e.endIndex);
      if (!isAlreadyCovered && !val.startsWith('482-91')) {
        entities.push({
          id: `phone-${match.index}`,
          type: 'PHONE',
          value: match[0],
          confidence: 0.94,
          startIndex: match.index,
          endIndex: match.index + match[0].length,
          severity: 'medium',
          suggestion: 'Personal telephone / mobile contact number.'
        });
      }
    }
  }

  // 7. Contextual Names Scanner
  if (settings.detectors.names) {
    const nameContextRegex = /\b(?:customer|user|patient|employee|client|dr\.|mr\.|ms\.|mrs\.)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b|\b([A-Z][a-z]+)'s\s+(?:email|phone|account|record|ssn|pan|id)\b/gi;
    let match;
    while ((match = nameContextRegex.exec(text)) !== null) {
      const matchedName = match[1] || match[2];
      if (matchedName && matchedName.length > 2) {
        const fullMatch = match[0];
        const nameOffset = fullMatch.indexOf(matchedName);
        const startIndex = match.index + nameOffset;
        const endIndex = startIndex + matchedName.length;

        const isAlreadyCovered = entities.some(e => startIndex >= e.startIndex && startIndex < e.endIndex);
        if (!isAlreadyCovered) {
          entities.push({
            id: `name-${startIndex}`,
            type: 'NAME',
            value: matchedName,
            confidence: 0.88,
            startIndex,
            endIndex,
            severity: 'low',
            suggestion: 'Identifiable individual proper name in customer context.'
          });
        }
      }
    }
  }

  // 8. Medical ID & HIPAA
  if (settings.detectors.healthRecords) {
    const medRegex = /\b(#MED-\d+|Lisinopril \d+mg|Diagnosis: [^\n\.,]+|cardiomyopathy|Hypertension|DOB:\s*\d{4}-\d{2}-\d{2})\b/gi;
    let match;
    while ((match = medRegex.exec(text)) !== null) {
      const isAlreadyCovered = entities.some(e => match!.index >= e.startIndex && match!.index < e.endIndex);
      if (!isAlreadyCovered) {
        entities.push({
          id: `med-${match.index}`,
          type: 'MEDICAL_ID',
          value: match[0],
          confidence: 0.94,
          startIndex: match.index,
          endIndex: match.index + match[0].length,
          severity: 'high',
          suggestion: 'Protected Health Information (PHI) subject to HIPAA regulations.'
        });
      }
    }
  }

  // 9. IP Addresses
  if (settings.detectors.ipAddresses) {
    const ipRegex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g;
    let match;
    while ((match = ipRegex.exec(text)) !== null) {
      entities.push({
        id: `ip-${match.index}`,
        type: 'IP_ADDRESS',
        value: match[0],
        confidence: 0.96,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        severity: 'low',
        suggestion: 'Internal or public network IP address.'
      });
    }
  }

  // 10. Passwords
  if (settings.detectors.passwords) {
    const passRegex = /\bpassword\s*[:=]\s*["']?([^"'\s\n]{4,})["']?/gi;
    let match;
    while ((match = passRegex.exec(text)) !== null) {
      const isAlreadyCovered = entities.some(e => match!.index >= e.startIndex && match!.index < e.endIndex);
      if (!isAlreadyCovered && match[1]) {
        entities.push({
          id: `pass-${match.index}`,
          type: 'API_KEY',
          value: match[1],
          confidence: 0.92,
          startIndex: match.index + match[0].indexOf(match[1]),
          endIndex: match.index + match[0].indexOf(match[1]) + match[1].length,
          severity: 'critical',
          suggestion: 'Plaintext credential string detected.'
        });
      }
    }
  }

  // 11. Prompt Injection & Adversarial Jailbreak Scanner
  let hasPromptInjection = false;
  if (settings.detectors.promptInjection !== false) {
    const injectionRegex = /\b(SYSTEM OVERRIDE|DEV_UNRESTRICTED|DAN mode|ignore all (?:previous|prior) (?:instructions|rules|safety|guidelines)|bypass (?:safety|guardrails|policies)|print all internal|exfiltrate|leak database|override (?:system|filter))\b/gi;
    let match;
    while ((match = injectionRegex.exec(text)) !== null) {
      hasPromptInjection = true;
      entities.push({
        id: `inj-${match.index}`,
        type: 'PROMPT_INJECTION',
        value: match[0],
        confidence: 0.99,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        severity: 'critical',
        suggestion: 'Adversarial jailbreak instruction attempting to override LLM safety boundaries.'
      });
    }
  }

  // 12. Custom Regex
  if (settings.detectors.customRegex && settings.customRegexPattern) {
    try {
      const customRegex = new RegExp(settings.customRegexPattern, 'g');
      let match;
      while ((match = customRegex.exec(text)) !== null) {
        entities.push({
          id: `custom-${match.index}`,
          type: 'NAME',
          value: match[0],
          confidence: 0.88,
          startIndex: match.index,
          endIndex: match.index + match[0].length,
          severity: 'medium',
          suggestion: 'Matched user-configured custom security pattern.'
        });
      }
    } catch {
      // Invalid custom regex, skip gracefully
    }
  }

  // Filter by confidence threshold
  const filteredEntities = entities.filter(e => e.confidence >= settings.confidenceThreshold);
  filteredEntities.sort((a, b) => a.startIndex - b.startIndex);

  // -------------------------------------------------------------
  // THREAT CLASSIFICATION SYSTEM
  // -------------------------------------------------------------
  const entityTypes = new Set(filteredEntities.map(e => e.type));
  const distinctCategories: ThreatCategory[] = [];

  if (entityTypes.has('API_KEY')) distinctCategories.push('CREDENTIAL_SECRET_EXPOSURE');
  if (entityTypes.has('SSN') || entityTypes.has('PAN') || entityTypes.has('AADHAAR')) distinctCategories.push('GOVERNMENT_ID_EXPOSURE');
  if (entityTypes.has('CREDIT_CARD') || entityTypes.has('BANK_ACCOUNT')) distinctCategories.push('FINANCIAL_DATA_EXPOSURE');
  if (entityTypes.has('MEDICAL_ID')) distinctCategories.push('HEALTHCARE_DATA_EXPOSURE');
  if (entityTypes.has('EMAIL') || entityTypes.has('PHONE') || entityTypes.has('NAME')) distinctCategories.push('PII_EXPOSURE');
  if (entityTypes.has('PROMPT_INJECTION') || hasPromptInjection) distinctCategories.push('PROMPT_INJECTION');

  let primaryCategory: ThreatCategory = 'SAFE_NORMAL';
  let categoryLabel = 'Safe / Normal Query';

  if (distinctCategories.length > 1) {
    primaryCategory = 'MULTIPLE_THREATS';
    categoryLabel = `Multiple Threats (${distinctCategories.length} Vector Alert)`;
  } else if (distinctCategories.length === 1) {
    primaryCategory = distinctCategories[0];
    switch (primaryCategory) {
      case 'CREDENTIAL_SECRET_EXPOSURE':
        categoryLabel = 'API Secret & Credential Exposure';
        break;
      case 'GOVERNMENT_ID_EXPOSURE':
        categoryLabel = 'Government ID Exposure (PAN/Aadhaar/SSN)';
        break;
      case 'FINANCIAL_DATA_EXPOSURE':
        categoryLabel = 'Financial & Payment Data Exposure (PCI-DSS)';
        break;
      case 'HEALTHCARE_DATA_EXPOSURE':
        categoryLabel = 'Healthcare & PHI Data Exposure (HIPAA)';
        break;
      case 'PROMPT_INJECTION':
        categoryLabel = 'Prompt Injection & Jailbreak Attack';
        break;
      case 'PII_EXPOSURE':
        categoryLabel = 'Customer PII Exposure';
        break;
      default:
        categoryLabel = 'Safe / Normal';
    }
  }

  // -------------------------------------------------------------
  // INTELLIGENT RISK SCORING (0 to 100)
  // -------------------------------------------------------------
  let rawRisk = 0;
  for (const e of filteredEntities) {
    if (e.type === 'PROMPT_INJECTION') rawRisk += 60;
    else if (e.type === 'API_KEY') rawRisk += 50;
    else if (e.type === 'SSN' || e.type === 'PAN' || e.type === 'AADHAAR') rawRisk += 45;
    else if (e.type === 'CREDIT_CARD' || e.type === 'BANK_ACCOUNT') rawRisk += 45;
    else if (e.type === 'MEDICAL_ID') rawRisk += 35;
    else if (e.type === 'EMAIL' || e.type === 'PHONE') rawRisk += 15;
    else rawRisk += 10;
  }

  // Multiplier for compound multi-vector attacks
  if (distinctCategories.length >= 2) {
    rawRisk = Math.round(rawRisk * 1.35);
  }

  const finalRiskScore = Math.min(100, Math.max(0, rawRisk));

  let threatSeverity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
  if (finalRiskScore >= 80) threatSeverity = 'CRITICAL';
  else if (finalRiskScore >= 50) threatSeverity = 'HIGH';
  else if (finalRiskScore >= 20) threatSeverity = 'MEDIUM';
  else threatSeverity = 'LOW';

  const threatClassification: ThreatClassification = {
    primaryCategory,
    categoryLabel,
    detectedThreats: Array.from(new Set(filteredEntities.map(e => e.type))),
    severity: threatSeverity,
    riskScore: finalRiskScore,
    hasPromptInjection: hasPromptInjection || entityTypes.has('PROMPT_INJECTION'),
    explanation: filteredEntities.length === 0
      ? 'No sensitive entities detected. Query is within safe compliance boundaries.'
      : `Detected ${filteredEntities.length} sensitive entity instance(s) across [${distinctCategories.join(', ')}].`
  };

  // -------------------------------------------------------------
  // ZERO-TRUST POLICY DECISION ENGINE
  // -------------------------------------------------------------
  const blockedCategories: string[] = [];
  const maskedCategories: string[] = [];

  for (const ent of filteredEntities) {
    if (ent.type === 'API_KEY') {
      if (settings.policy.apiSecrets === 'BLOCK') blockedCategories.push('API_KEY');
      else if (settings.policy.apiSecrets === 'REDACT') maskedCategories.push('API_KEY');
    } else if (ent.type === 'SSN' || ent.type === 'PAN' || ent.type === 'AADHAAR') {
      if (settings.policy.govtId === 'BLOCK') blockedCategories.push(ent.type);
      else if (settings.policy.govtId === 'REDACT') maskedCategories.push(ent.type);
    } else if (ent.type === 'CREDIT_CARD' || ent.type === 'BANK_ACCOUNT') {
      if (settings.policy.creditCard === 'BLOCK') blockedCategories.push(ent.type);
      else if (settings.policy.creditCard === 'REDACT') maskedCategories.push(ent.type);
    } else if (ent.type === 'MEDICAL_ID') {
      if (settings.policy.healthRecords === 'BLOCK') blockedCategories.push('MEDICAL_ID');
      else maskedCategories.push('MEDICAL_ID');
    } else if (ent.type === 'PROMPT_INJECTION') {
      if (settings.policy.promptInjection !== 'ALLOW') blockedCategories.push('PROMPT_INJECTION');
    } else if (ent.type === 'EMAIL' || ent.type === 'PHONE') {
      if (settings.policy.emailPhone === 'BLOCK') blockedCategories.push(ent.type);
      else if (settings.policy.emailPhone === 'MASK') maskedCategories.push(ent.type);
    } else if (ent.type === 'NAME') {
      if (settings.policy.names === 'MASK') maskedCategories.push('NAME');
    } else if (ent.type === 'IP_ADDRESS') {
      if (settings.policy.ipAddresses === 'MASK') maskedCategories.push('IP_ADDRESS');
    }
  }

  // Max risk score trigger
  const maxRiskThreshold = settings.policy.maxRiskScoreBeforeBlock ?? 75;
  if (finalRiskScore >= maxRiskThreshold && filteredEntities.length > 0 && blockedCategories.length === 0) {
    blockedCategories.push('EXCEEDS_MAX_RISK_THRESHOLD');
  }

  const uniqueBlocked = Array.from(new Set(blockedCategories));
  const uniqueMasked = Array.from(new Set(maskedCategories));

  let decision: GateDecision;
  if (uniqueBlocked.length > 0) {
    let blockReason = 'Credentials & statutory identity tokens must never be sent to an external AI model.';
    if (uniqueBlocked.includes('PROMPT_INJECTION')) {
      blockReason = 'Prompt injection & system override attacks are strictly blocked at the gateway boundary.';
    } else if (uniqueBlocked.includes('API_KEY')) {
      blockReason = 'Developer API keys and cloud secrets must never be sent to an external AI model.';
    } else if (uniqueBlocked.includes('PAN') || uniqueBlocked.includes('AADHAAR') || uniqueBlocked.includes('SSN')) {
      blockReason = 'Statutory government identification numbers are prohibited from unencrypted LLM processing.';
    } else if (uniqueBlocked.includes('CREDIT_CARD') || uniqueBlocked.includes('BANK_ACCOUNT')) {
      blockReason = 'Live credit card numbers and banking transit tokens violate PCI-DSS compliance requirements.';
    } else if (uniqueBlocked.includes('EXCEEDS_MAX_RISK_THRESHOLD')) {
      blockReason = `Risk score (${finalRiskScore}/100) exceeded maximum policy tolerance threshold (${maxRiskThreshold}/100).`;
    }

    decision = {
      action: 'BLOCK',
      reason: `Blocked by Policy: Sensitive [${uniqueBlocked.join(', ')}] detected. ${blockReason}`,
      blockedCategories: uniqueBlocked,
      maskedCategories: uniqueMasked,
      whyExplanation: {
        threat: categoryLabel,
        risk: `${finalRiskScore}/100 — ${threatSeverity}`,
        detected: uniqueBlocked,
        policy: 'BLOCK',
        reason: blockReason
      }
    };
  } else if (filteredEntities.length > 0) {
    decision = {
      action: 'SANITIZE_AND_SEND',
      reason: `Protected: ${filteredEntities.length} sensitive token(s) sanitized (${uniqueMasked.join(', ')}). Sanitized prompt authorized for model dispatch.`,
      blockedCategories: [],
      maskedCategories: uniqueMasked,
      whyExplanation: {
        threat: categoryLabel,
        risk: `${finalRiskScore}/100 — ${threatSeverity}`,
        detected: uniqueMasked,
        policy: 'MASK',
        reason: 'Sensitive entities were safely scrubbed. The sanitized payload is compliant for downstream Gemini dispatch.'
      }
    };
  } else {
    decision = {
      action: 'ALLOW',
      reason: 'Safe: No sensitive PII, credentials, or malicious prompt injection patterns detected.',
      blockedCategories: [],
      maskedCategories: [],
      whyExplanation: {
        threat: 'Safe / Normal Input',
        risk: `${finalRiskScore}/100 — LOW`,
        detected: ['None'],
        policy: 'ALLOW',
        reason: 'Prompt contains no sensitive data or policy violations.'
      }
    };
  }

  // -------------------------------------------------------------
  // GENERATE REDACTED PAYLOAD
  // -------------------------------------------------------------
  let redactedText = text;
  const reversedEntities = [...filteredEntities].sort((a, b) => b.startIndex - a.startIndex);

  for (const entity of reversedEntities) {
    let replacement = `[REDACTED_${entity.type}]`;
    if (settings.redactionStyle === 'MASK_CHAR') {
      replacement = (settings.maskChar || '*').repeat(Math.max(4, entity.value.length));
    } else if (settings.redactionStyle === 'HASH') {
      const hashStr = Math.abs(entity.value.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString(16).padStart(8, '0');
      replacement = `[SHA256:${hashStr.slice(0, 8)}]`;
    } else if (settings.redactionStyle === 'BLUR') {
      replacement = `████████`;
    }

    redactedText = redactedText.substring(0, entity.startIndex) + replacement + redactedText.substring(entity.endIndex);
  }

  const endTime = performance.now();
  const scanDurationMs = Math.max(1.2, Math.round((endTime - startTime) * 10) / 10);

  return {
    originalText: text,
    redactedText,
    detectedEntities: filteredEntities,
    riskScore: finalRiskScore,
    threatClassification,
    scanDurationMs,
    timestamp: new Date().toLocaleTimeString(),
    decision
  };
}
