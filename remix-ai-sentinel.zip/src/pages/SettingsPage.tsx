import React, { useState, useEffect } from 'react';
import { SentinelSettings, PolicySettings } from '../types';
import { StSuccess, StInfo } from '../components/StreamlitCallouts';
import { Settings, Sliders, ShieldCheck, Bell, Save, Terminal, Code2, RefreshCw, Lock, Sparkles, Key, CheckCircle, ShieldAlert } from 'lucide-react';

interface SettingsPageProps {
  settings: SentinelSettings;
  onUpdateSettings: (newSettings: SentinelSettings) => void;
  onOpenPythonCode: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onUpdateSettings,
  onOpenPythonCode
}) => {
  const [localSettings, setLocalSettings] = useState<SentinelSettings>(settings);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [apiStatus, setApiStatus] = useState<{ isConfigured: boolean; model: string; mode: string } | null>(null);

  useEffect(() => {
    fetch('/api/gemini/status')
      .then(res => res.json())
      .then(data => setApiStatus(data))
      .catch(() => setApiStatus({ isConfigured: false, model: 'gemini-3.7-flash', mode: 'SIMULATION_FALLBACK' }));
  }, []);

  const handleDetectorToggle = (key: keyof SentinelSettings['detectors']) => {
    setLocalSettings(prev => ({
      ...prev,
      detectors: {
        ...prev.detectors,
        [key]: !prev.detectors[key]
      }
    }));
  };

  const handlePolicyChange = (field: keyof PolicySettings, value: any) => {
    setLocalSettings(prev => ({
      ...prev,
      policy: {
        ...prev.policy,
        [field]: value
      }
    }));
  };

  const handleSave = () => {
    onUpdateSettings(localSettings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Title */}
      <div className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <span>⚙️</span>
            <span>Sentinel Firewall & Policy Configuration</span>
          </h1>
          <p className="text-slate-600 text-sm mt-1.5">
            Configure zero-trust egress policies (ALLOW / MASK / BLOCK), PII detectors, and live Gemini API gateway settings.
          </p>
        </div>

        <button
          id="btn-save-settings-top"
          onClick={handleSave}
          className="flex items-center gap-2 px-4 py-2 bg-[#ff4b4b] hover:bg-[#e03a3a] text-white text-xs sm:text-sm font-semibold rounded-md transition-colors shadow-xs"
        >
          <Save className="w-4 h-4" />
          <span>Save Sentinel Settings</span>
        </button>
      </div>

      {saveSuccess && (
        <StSuccess title="Configuration Saved Successfully!">
          Zero-trust firewall rules updated. Egress policy and sensitivity threshold ({Math.round(localSettings.confidenceThreshold * 100)}%) are actively enforced on all AI Playground requests.
        </StSuccess>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Policies and Firewall Rules */}
        <div className="lg:col-span-2 space-y-6">
          {/* Zero-Trust Egress Policy Configuration (Phase 2 Core Requirement) */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-600" />
                <span>Zero-Trust Policy Engine (Action on Detection)</span>
              </h2>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Active Egress Guard
              </span>
            </div>

            <p className="text-xs text-slate-600">
              Configure how the firewall treats specific classes of sensitive information before sending prompts to the Gemini model.
            </p>

            <div className="space-y-3 pt-1">
              {/* Rule 1: Email & Phone */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Email & Phone Numbers</span>
                  <span className="text-slate-500 text-[11px]">Customer contact identifiers</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['MASK', 'BLOCK', 'ALLOW'] as const).map(action => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => handlePolicyChange('emailPhone', action)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        localSettings.policy.emailPhone === action
                          ? action === 'BLOCK'
                            ? 'bg-red-600 text-white'
                            : action === 'MASK'
                            ? 'bg-amber-600 text-white'
                            : 'bg-emerald-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rule 2: Govt IDs (PAN, Aadhaar, SSN) */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Government IDs (Indian PAN, Aadhaar, US SSN)</span>
                  <span className="text-slate-500 text-[11px]">Statutory national identity numbers</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['BLOCK', 'REDACT', 'ALLOW'] as const).map(action => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => handlePolicyChange('govtId', action)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        localSettings.policy.govtId === action
                          ? action === 'BLOCK'
                            ? 'bg-red-600 text-white'
                            : action === 'REDACT'
                            ? 'bg-amber-600 text-white'
                            : 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rule 3: Credit Cards */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Credit & Debit Cards (PCI-DSS)</span>
                  <span className="text-slate-500 text-[11px]">Primary account numbers & CVV tokens</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['BLOCK', 'REDACT', 'ALLOW'] as const).map(action => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => handlePolicyChange('creditCard', action)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        localSettings.policy.creditCard === action
                          ? action === 'BLOCK'
                            ? 'bg-red-600 text-white'
                            : action === 'REDACT'
                            ? 'bg-amber-600 text-white'
                            : 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rule 4: API Keys & Secrets */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">API Keys & Cloud Secrets</span>
                  <span className="text-slate-500 text-[11px]">SECRET_API_KEY, sk-tokens, AWS/GCP keys</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['BLOCK', 'REDACT', 'ALLOW'] as const).map(action => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => handlePolicyChange('apiSecrets', action)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        localSettings.policy.apiSecrets === action
                          ? action === 'BLOCK'
                            ? 'bg-red-600 text-white'
                            : action === 'REDACT'
                            ? 'bg-amber-600 text-white'
                            : 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rule 5: Healthcare & PHI Records (HIPAA) */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Healthcare & Medical Data (HIPAA)</span>
                  <span className="text-slate-500 text-[11px]">Clinical diagnoses, prescriptions, #MED IDs</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['BLOCK', 'REDACT', 'ALLOW'] as const).map(action => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => handlePolicyChange('healthRecords', action)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        (localSettings.policy.healthRecords || 'BLOCK') === action
                          ? action === 'BLOCK'
                            ? 'bg-red-600 text-white'
                            : action === 'REDACT'
                            ? 'bg-amber-600 text-white'
                            : 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rule 6: Prompt Injection & Adversarial Jailbreaks (Phase 3) */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Prompt Injections & Jailbreaks (Phase 3)</span>
                  <span className="text-slate-500 text-[11px]">SYSTEM OVERRIDE, DAN mode, instruction hijacking</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['BLOCK', 'REDACT', 'ALLOW'] as const).map(action => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => handlePolicyChange('promptInjection', action)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        (localSettings.policy.promptInjection || 'BLOCK') === action
                          ? action === 'BLOCK'
                            ? 'bg-red-600 text-white'
                            : action === 'REDACT'
                            ? 'bg-amber-600 text-white'
                            : 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Max Risk Score Trigger */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block">Maximum Risk Score Tolerance Before Auto-Block</span>
                    <span className="text-slate-500 text-[11px]">Automatically block compound multi-threat attacks</span>
                  </div>
                  <span className="font-bold text-sm font-mono text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                    {localSettings.policy.maxRiskScoreBeforeBlock ?? 75}/100
                  </span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="100"
                  step="5"
                  value={localSettings.policy.maxRiskScoreBeforeBlock ?? 75}
                  onChange={(e) => handlePolicyChange('maxRiskScoreBeforeBlock', parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-[#ff4b4b]"
                />
              </div>
            </div>
          </div>

          {/* Active Detectors */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-4">
            <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <ShieldCheck className="w-4 h-4 text-[#ff4b4b]" />
              <span>Active Data Loss Prevention (DLP) Detectors</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.pan}
                  onChange={() => handleDetectorToggle('pan')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">Indian PAN Card (Tax ID)</span>
                  <span className="text-slate-500 text-[11px] font-mono">[A-Z]&#123;5&#125;[0-9]&#123;4&#125;[A-Z] pattern</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.aadhaar}
                  onChange={() => handleDetectorToggle('aadhaar')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">Indian Aadhaar (UIDAI)</span>
                  <span className="text-slate-500 text-[11px]">12-digit national identification numbers</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.ssn}
                  onChange={() => handleDetectorToggle('ssn')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">Social Security Numbers (SSN)</span>
                  <span className="text-slate-500 text-[11px]">US 9-digit social security patterns</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.creditCard}
                  onChange={() => handleDetectorToggle('creditCard')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">Credit & Debit Cards</span>
                  <span className="text-slate-500 text-[11px]">Visa, MasterCard, Amex, RuPay</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.apiKeys}
                  onChange={() => handleDetectorToggle('apiKeys')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">API Keys & Cloud Secrets</span>
                  <span className="text-slate-500 text-[11px]">SECRET_API_KEY, sk-, AIza, AWS tokens</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.names}
                  onChange={() => handleDetectorToggle('names')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">Proper Names in Context</span>
                  <span className="text-slate-500 text-[11px]">"customer Priya", "employee Rajesh", etc.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.emailPhone}
                  onChange={() => handleDetectorToggle('emailPhone')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">Email & Phone Numbers</span>
                  <span className="text-slate-500 text-[11px]">US & Indian (+91) formats</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.healthRecords}
                  onChange={() => handleDetectorToggle('healthRecords')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block">HIPAA Medical Records</span>
                  <span className="text-slate-500 text-[11px]">Prescriptions, diagnosis, health IDs</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-red-200 bg-red-50/30 hover:bg-red-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.promptInjection ?? true}
                  onChange={() => handleDetectorToggle('promptInjection')}
                  className="mt-0.5 text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <div>
                  <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                    <span>Prompt Injection & DAN Heuristics</span>
                    <span className="text-[10px] bg-red-100 text-red-700 font-bold px-1 rounded">P3</span>
                  </span>
                  <span className="text-slate-500 text-[11px]">Instruction override & bypass detection</span>
                </div>
              </label>
            </div>

            {/* Custom Regex Pattern Option */}
            <div className="pt-2 border-t border-slate-100">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800 mb-2">
                <input
                  type="checkbox"
                  checked={localSettings.detectors.customRegex}
                  onChange={() => handleDetectorToggle('customRegex')}
                  className="text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <span>Enable Custom Regex Pattern Matching (e.g. Employee Badges)</span>
              </label>

              {localSettings.detectors.customRegex && (
                <input
                  type="text"
                  value={localSettings.customRegexPattern}
                  onChange={(e) => setLocalSettings({ ...localSettings, customRegexPattern: e.target.value })}
                  placeholder="Regex pattern e.g. EMP-[0-9]{5}"
                  className="w-full font-mono text-xs p-2.5 rounded bg-slate-50 border border-slate-300 text-slate-900 outline-none focus:ring-2 focus:ring-[#ff4b4b]"
                />
              )}
            </div>
          </div>

          {/* Threshold & Strictness */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-4">
            <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <Sliders className="w-4 h-4 text-blue-600" />
              <span>Sensitivity & Threshold Controls</span>
            </h2>

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
                <span className="text-slate-700">Minimum Confidence Score to Trigger Redaction:</span>
                <span className="font-bold text-slate-900 font-mono text-sm">
                  {Math.round(localSettings.confidenceThreshold * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.50"
                max="0.99"
                step="0.05"
                value={localSettings.confidenceThreshold}
                onChange={(e) => setLocalSettings({ ...localSettings, confidenceThreshold: parseFloat(e.target.value) })}
                className="w-full accent-[#ff4b4b] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>50% (High Recall / Catches everything)</span>
                <span>99% (High Precision / Zero false alarms)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Gemini Status, Webhooks & Python Code */}
        <div className="space-y-6">
          {/* Gemini Model Gateway Status */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
              <Key className="w-4 h-4 text-blue-600" />
              <span>Gemini Model Integration</span>
            </div>

            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 font-medium">Target Model:</span>
                <span className="font-mono font-bold text-slate-900">gemini-3.7-flash</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 font-medium">Gateway Status:</span>
                {apiStatus?.isConfigured ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Live Inference Active</span>
                  </span>
                ) : (
                  <span className="text-amber-700 font-bold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Demo / Simulation Mode</span>
                  </span>
                )}
              </div>
            </div>

            <p className="text-[11px] text-slate-500 leading-relaxed">
              To enable live cloud inference with Gemini, configure <code>GEMINI_API_KEY</code> in your environment or Google AI Studio secrets. The app seamlessly operates in zero-setup simulation mode if no key is present.
            </p>
          </div>

          {/* Notifications Webhook */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-4">
            <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <Bell className="w-4 h-4 text-purple-600" />
              <span>Incident Webhooks</span>
            </h2>

            <div className="space-y-3 text-xs">
              <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-800">
                <input
                  type="checkbox"
                  checked={localSettings.notifySlack}
                  onChange={(e) => setLocalSettings({ ...localSettings, notifySlack: e.target.checked })}
                  className="text-[#ff4b4b] focus:ring-[#ff4b4b] rounded"
                />
                <span>Alert SecOps on Critical PII / Leaks</span>
              </label>

              {localSettings.notifySlack && (
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-500 font-medium">Slack / Discord Webhook URL</label>
                  <input
                    type="text"
                    value={localSettings.slackWebhookUrl}
                    onChange={(e) => setLocalSettings({ ...localSettings, slackWebhookUrl: e.target.value })}
                    className="w-full text-xs font-mono p-2 rounded bg-slate-50 border border-slate-300 text-slate-800 outline-none focus:ring-2 focus:ring-[#ff4b4b]"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Python Export Card */}
          <div className="bg-slate-900 text-white rounded-lg p-5 border border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-red-400">
              <Code2 className="w-4 h-4" />
              <span>Streamlit Architecture</span>
            </div>
            <h3 className="font-bold text-slate-100 text-sm">Download Phase 2 app.py</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Export the full Python Streamlit script with the AI Playground, Gemini integration, and PII firewall.
            </p>

            <button
              id="btn-open-code-modal"
              onClick={onOpenPythonCode}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-[#ff4b4b] hover:bg-[#e03a3a] text-white text-xs font-semibold rounded-md transition-colors shadow-xs"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>View app.py Source Code</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
