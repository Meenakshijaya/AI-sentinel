import React, { useState } from 'react';
import { SAMPLE_PROMPTS } from '../data/mockData';
import { runPIIScan } from '../utils/piiEngine';
import { PIIEntity, ScanResult, SentinelSettings } from '../types';
import { StSuccess, StWarning, StError, StInfo } from '../components/StreamlitCallouts';
import { ShieldCheck, ShieldAlert, Copy, Check, Sparkles, RefreshCw, AlertTriangle, FileCheck, Layers } from 'lucide-react';

interface PIIScannerPageProps {
  settings: SentinelSettings;
  onUpdateSettings: (newSettings: SentinelSettings) => void;
}

export const PIIScannerPage: React.FC<PIIScannerPageProps> = ({ settings, onUpdateSettings }) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('customer_support');
  const [inputText, setInputText] = useState<string>(SAMPLE_PROMPTS[0].text);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(() => runPIIScan(SAMPLE_PROMPTS[0].text, settings));
  const [copied, setCopied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'redacted' | 'entities' | 'diff'>('redacted');

  const handleSelectPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    if (presetId === 'custom') {
      setInputText('');
      setScanResult(null);
    } else {
      const preset = SAMPLE_PROMPTS.find(p => p.id === presetId);
      if (preset) {
        setInputText(preset.text);
        setScanResult(runPIIScan(preset.text, settings));
      }
    }
  };

  const handleExecuteScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      const result = runPIIScan(inputText, settings);
      setScanResult(result);
      setIsScanning(false);
    }, 250); // slight realistic scanner latency simulation
  };

  const handleCopyRedacted = () => {
    if (scanResult) {
      navigator.clipboard.writeText(scanResult.redactedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getSeverityBadgeClass = (sev: PIIEntity['severity']) => {
    switch (sev) {
      case 'critical':
        return 'bg-red-100 text-red-700 border-red-200 font-bold';
      case 'high':
        return 'bg-amber-100 text-amber-800 border-amber-200 font-semibold';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Streamlit Title */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
          <span>🔍</span>
          <span>Real-Time PII & Secret Scanner</span>
        </h1>
        <p className="text-slate-600 text-sm mt-1.5">
          Test real-time DLP inspection. Inspect how AI Sentinel detects, scores, and neutralizes sensitive data before forwarding to LLMs.
        </p>
      </div>

      {/* Preset Selector */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
        <div>
          <label className="text-xs font-bold text-slate-700 block mb-1.5 uppercase tracking-wide">
            Select Sample Prompt Scenario (st.selectbox)
          </label>
          <select
            id="select-sample-preset"
            value={selectedPresetId}
            onChange={(e) => handleSelectPreset(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-sm rounded-md px-3 py-2.5 focus:ring-2 focus:ring-[#ff4b4b] focus:border-transparent outline-none"
          >
            {SAMPLE_PROMPTS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title} — {p.description}
              </option>
            ))}
            <option value="custom">✏️ Custom Prompt (Enter your own text)...</option>
          </select>
        </div>

        {/* Text Area */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">
              Prompt / Payload Content (st.text_area)
            </label>
            <span className="text-xs text-slate-500 font-mono">
              {inputText.length} characters • {inputText.split(/\s+/).filter(Boolean).length} words
            </span>
          </div>
          <textarea
            id="textarea-prompt-input"
            rows={6}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste your prompt, document excerpt, or API query here..."
            className="w-full font-mono text-xs sm:text-sm bg-white border border-slate-300 text-slate-900 rounded-md p-3.5 focus:ring-2 focus:ring-[#ff4b4b] focus:border-transparent outline-none resize-y"
          />
        </div>

        {/* Controls & Formatting Options */}
        <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <span className="font-bold text-slate-700">Redaction Style:</span>
            {(['ENTITY_TAG', 'MASK_CHAR', 'HASH', 'BLUR'] as const).map((style) => (
              <label key={style} className="inline-flex items-center gap-1.5 cursor-pointer text-slate-700">
                <input
                  type="radio"
                  name="redactionStyle"
                  checked={settings.redactionStyle === style}
                  onChange={() => onUpdateSettings({ ...settings, redactionStyle: style })}
                  className="text-[#ff4b4b] focus:ring-[#ff4b4b]"
                />
                <span className="font-medium">
                  {style === 'ENTITY_TAG' && '[TAG]'}
                  {style === 'MASK_CHAR' && '***'}
                  {style === 'HASH' && 'SHA256'}
                  {style === 'BLUR' && 'Blur'}
                </span>
              </label>
            ))}
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              id="btn-run-pii-scan"
              onClick={handleExecuteScan}
              disabled={isScanning || !inputText.trim()}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-[#ff4b4b] hover:bg-[#e03a3a] disabled:bg-slate-300 text-white text-xs sm:text-sm font-semibold rounded-md transition-colors shadow-xs"
            >
              {isScanning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Scanning Payload...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Run Security Scan</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Scan Results Section */}
      {scanResult && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Summary Banner */}
          {scanResult.detectedEntities.length > 0 ? (
            <div className="p-4 rounded-lg bg-red-50 border border-red-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-red-950 text-sm">
                    {scanResult.detectedEntities.length} Sensitive {scanResult.detectedEntities.length === 1 ? 'Entity' : 'Entities'} Intercepted
                  </h3>
                  <p className="text-xs text-red-800">
                    High risk data identified. AI Sentinel has sanitized the prompt before forwarding.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center">
                <div className="text-right">
                  <span className="text-[11px] text-slate-500 block uppercase font-medium">Risk Score</span>
                  <span className="text-base font-bold text-red-700 font-mono">
                    {scanResult.riskScore} / 100
                  </span>
                </div>
                <div className="text-right pl-3 border-l border-red-200">
                  <span className="text-[11px] text-slate-500 block uppercase font-medium">Scan Time</span>
                  <span className="text-base font-bold text-slate-800 font-mono">
                    {scanResult.scanDurationMs} ms
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <StSuccess title="Zero Vulnerabilities Detected">
              Scan finished in {scanResult.scanDurationMs}ms. No PII, HIPAA, or secret tokens detected. This payload is safe to forward.
            </StSuccess>
          )}

          {/* Results Tabs */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
            <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2 gap-2">
              <button
                onClick={() => setActiveTab('redacted')}
                className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-t-md border-t-2 transition-all ${
                  activeTab === 'redacted'
                    ? 'border-[#ff4b4b] bg-white text-slate-900 shadow-xs'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileCheck className="w-3.5 h-3.5 text-[#ff4b4b]" />
                <span>Sanitized Prompt Preview</span>
              </button>

              <button
                onClick={() => setActiveTab('entities')}
                className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-t-md border-t-2 transition-all ${
                  activeTab === 'entities'
                    ? 'border-[#ff4b4b] bg-white text-slate-900 shadow-xs'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-blue-600" />
                <span>Entity Breakdown Table ({scanResult.detectedEntities.length})</span>
              </button>
            </div>

            <div className="p-5">
              {activeTab === 'redacted' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                      Sanitized Output (Ready for LLM Ingress)
                    </span>
                    <button
                      id="btn-copy-sanitized-prompt"
                      onClick={handleCopyRedacted}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md border border-slate-300 transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied to Clipboard!' : 'Copy Redacted Text'}</span>
                    </button>
                  </div>

                  <div className="p-4 rounded-md bg-slate-950 text-slate-100 font-mono text-xs leading-relaxed overflow-x-auto border border-slate-800">
                    <pre className="whitespace-pre-wrap">{scanResult.redactedText}</pre>
                  </div>
                </div>
              )}

              {activeTab === 'entities' && (
                <div>
                  {scanResult.detectedEntities.length === 0 ? (
                    <p className="text-sm text-slate-500 py-6 text-center">No entities to display.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 uppercase font-semibold">
                            <th className="py-2.5 px-3">Entity Type</th>
                            <th className="py-2.5 px-3">Detected Value</th>
                            <th className="py-2.5 px-3">Severity</th>
                            <th className="py-2.5 px-3">Confidence</th>
                            <th className="py-2.5 px-3">Security Policy</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-mono">
                          {scanResult.detectedEntities.map((ent) => (
                            <tr key={ent.id} className="hover:bg-slate-50 transition-colors">
                              <td className="py-2.5 px-3 font-bold text-slate-900 font-sans">
                                {ent.type}
                              </td>
                              <td className="py-2.5 px-3 text-red-600 font-semibold max-w-xs truncate">
                                {ent.value}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className={`px-2 py-0.5 rounded border text-[11px] uppercase ${getSeverityBadgeClass(ent.severity)}`}>
                                  {ent.severity}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-slate-700">
                                {Math.round(ent.confidence * 100)}%
                              </td>
                              <td className="py-2.5 px-3 text-slate-600 font-sans text-xs">
                                {ent.suggestion}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
