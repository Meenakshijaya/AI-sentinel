import React from 'react';
import { StreamlitMetric } from '../components/StreamlitMetric';
import { StInfo, StSuccess } from '../components/StreamlitCallouts';
import { PageType } from '../types';
import { ShieldCheck, ShieldAlert, FileText, Settings, ArrowRight, Zap, Lock, Terminal, CheckCircle, Sparkles, Bot } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: PageType) => void;
  onOpenPythonCode: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onOpenPythonCode }) => {
  return (
    <div className="max-w-6xl mx-auto space-y-7 pb-12">
      {/* Streamlit Title */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
          <span>🛡️</span>
          <span>AI Sentinel: Enterprise AI Security & Gemini Gateway</span>
        </h1>
        <p className="text-slate-600 text-sm mt-1.5 leading-relaxed">
          Zero-trust security gateway and DLP firewall for Generative AI applications. Intercepts, sanitizes, and audits sensitive data <strong>BEFORE</strong> prompts reach Gemini.
        </p>
      </div>

      {/* Streamlit Callout */}
      <StInfo title="Phase 2 Live Gemini Security Gateway Active">
        AI Sentinel is operating as a live security gateway. Every prompt dispatched to the Gemini model is inspected, scored for risk, and sanitized according to your configurable DLP policies.
      </StInfo>

      {/* Live Gateway Telemetry */}
      <div>
        <h2 className="text-base font-bold text-slate-800 mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#ff4b4b]" />
          <span>Live Gateway Telemetry</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StreamlitMetric
            id="metric-prompts-inspected"
            label="Prompts Inspected Today"
            value="14,892"
            delta="+18.4%"
            help="Total API prompts proxied through AI Sentinel firewall"
          />
          <StreamlitMetric
            id="metric-pii-redacted"
            label="PII Entities Redacted"
            value="843"
            delta="+4.2%"
            isInverse={true}
            help="Sensitive data entities scrubbed before reaching LLMs"
          />
          <StreamlitMetric
            id="metric-block-rate"
            label="Threat Block Rate"
            value="99.8%"
            delta="+0.1%"
            help="Percentage of identified threats blocked without false negatives"
          />
          <StreamlitMetric
            id="metric-avg-latency"
            label="Avg Gateway Latency"
            value="12.4 ms"
            delta="-2.1 ms"
            help="Overhead added by AI Sentinel scanner"
          />
        </div>
      </div>

      {/* Featured Banner: Launch Threat Simulator & AI Playground */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-xl p-6 border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-red-400 uppercase tracking-wider bg-red-400/10 px-2.5 py-1 rounded-md border border-red-400/20">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Phase 3 Feature • AI Threat Simulator & Intelligent Policy Engine</span>
            </div>
            <h3 className="text-xl font-bold text-slate-100">Live AI Threat Simulator</h3>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Demonstrate realistic adversarial attempts to leak sensitive PII, Indian PAN/Aadhaar IDs, live payment cards, production API secrets, medical PHI, and prompt injection jailbreaks into external AI models.
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              id="btn-hero-launch-threat-sim"
              onClick={() => onNavigate('threat_simulator')}
              className="flex items-center gap-2 px-5 py-3 bg-[#ff4b4b] hover:bg-[#e03a3a] text-white text-xs sm:text-sm font-bold rounded-lg transition-all shadow-md hover:scale-102"
            >
              <span>🔥 Launch Threat Simulator</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              id="btn-hero-launch-playground"
              onClick={() => onNavigate('ai_playground')}
              className="flex items-center gap-2 px-4 py-3 bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-bold rounded-lg transition-all border border-white/20"
            >
              <Bot className="w-4 h-4" />
              <span>AI Playground</span>
            </button>
          </div>
        </div>
      </div>

      {/* Core Modules Grid */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-slate-800">Explore AI Sentinel Modules</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Card 1: Threat Simulator */}
          <div className="bg-white rounded-lg p-5 border-2 border-red-200 shadow-xs flex flex-col justify-between hover:border-red-400 transition-all group bg-gradient-to-b from-red-50/20 to-transparent">
            <div>
              <div className="w-9 h-9 rounded-lg bg-red-100 text-red-600 flex items-center justify-center font-bold mb-3 group-hover:scale-105 transition-transform">
                <span className="text-lg">🔥</span>
              </div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-slate-900 text-sm">AI Threat Simulator</h3>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-100 text-red-700">NEW</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Execute 6 ready-made adversarial attacks (PII, Indian IDs, PCI cards, API tokens, PHI, jailbreaks) to evaluate zero-trust defense.
              </p>
            </div>
            <button
              id="btn-goto-threat-sim"
              onClick={() => onNavigate('threat_simulator')}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-md transition-colors shadow-xs"
            >
              <span>Launch Threat Lab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 2: AI Playground */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all group">
            <div>
              <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold mb-3 group-hover:scale-105 transition-transform">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">AI Playground (Live API)</h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Test the end-to-end gateway: scan, protect, and dispatch prompts to Gemini safely.
              </p>
            </div>
            <button
              id="btn-goto-playground"
              onClick={() => onNavigate('ai_playground')}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md transition-colors shadow-xs"
            >
              <span>Open Playground</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 3: PII Scanner */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all group">
            <div>
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold mb-3 group-hover:scale-105 transition-transform">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">PII & Secret Scanner</h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Dedicated regex inspector for SSNs, PAN, Aadhaar, credit cards, API keys, and PHI.
              </p>
            </div>
            <button
              id="btn-goto-scanner"
              onClick={() => onNavigate('pii_scanner')}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md border border-slate-300 transition-colors"
            >
              <span>Launch Scanner</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 4: Security Dashboard */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all group">
            <div>
              <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center font-bold mb-3 group-hover:scale-105 transition-transform">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">Security Dashboard</h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Real-time threat charts, risk severity distributions, and active jailbreak attack radar.
              </p>
            </div>
            <button
              id="btn-goto-dashboard"
              onClick={() => onNavigate('security_dashboard')}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md border border-slate-300 transition-colors"
            >
              <span>View Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 5: Audit Logs */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all group">
            <div>
              <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold mb-3 group-hover:scale-105 transition-transform">
                <FileText className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">Audit & Compliance Logs</h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Searchable, exportable audit trail of all sanitized prompts and policy violations.
              </p>
            </div>
            <button
              id="btn-goto-audit-logs"
              onClick={() => onNavigate('audit_logs')}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md border border-slate-300 transition-colors"
            >
              <span>Explore Logs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 6: Settings */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all group">
            <div>
              <div className="w-9 h-9 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-bold mb-3 group-hover:scale-105 transition-transform">
                <Settings className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">Intelligent Policy Engine</h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Configure Zero-Trust egress rules, prompt injection block actions, and risk thresholds.
              </p>
            </div>
            <button
              id="btn-goto-settings"
              onClick={() => onNavigate('settings')}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md border border-slate-300 transition-colors"
            >
              <span>Configure Policy</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Architecture & Flow Banner */}
      <div className="bg-slate-900 text-white rounded-xl p-6 border border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-400 uppercase tracking-wider">
              <Lock className="w-3.5 h-3.5" />
              <span>Zero-Trust AI Gateway Pipeline</span>
            </div>
            <h3 className="text-lg font-bold text-slate-100">How AI Sentinel Shields Your Gemini Pipeline</h3>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Every incoming prompt is scanned across 10+ sensitive data dimensions in parallel. High-risk PII is neutralized, policy violations are blocked, and only clean sanitized prompts are dispatched to downstream models.
            </p>
          </div>

          <button
            id="btn-quick-view-python"
            onClick={onOpenPythonCode}
            className="shrink-0 flex items-center gap-2 px-4 py-2 bg-[#ff4b4b] hover:bg-[#e03a3a] text-white text-xs font-semibold rounded-lg transition-colors shadow-sm"
          >
            <Terminal className="w-4 h-4" />
            <span>View Streamlit Code (app.py)</span>
          </button>
        </div>
      </div>

      {/* Hackathon Milestone Checklist */}
      <div className="bg-white rounded-lg p-5 border border-slate-200">
        <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>Hackathon Milestone: Phase 2 Deliverables</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          <div className="p-2.5 rounded bg-emerald-50/70 border border-emerald-200 text-emerald-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Live AI Playground Page</span>
          </div>
          <div className="p-2.5 rounded bg-emerald-50/70 border border-emerald-200 text-emerald-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Secure Server-Side Gemini API Proxy</span>
          </div>
          <div className="p-2.5 rounded bg-emerald-50/70 border border-emerald-200 text-emerald-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Zero-Trust Policy Engine (ALLOW / MASK / BLOCK)</span>
          </div>
          <div className="p-2.5 rounded bg-emerald-50/70 border border-emerald-200 text-emerald-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Indian PAN & Aadhaar Identifiers</span>
          </div>
          <div className="p-2.5 rounded bg-emerald-50/70 border border-emerald-200 text-emerald-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Automated Tamper-Evident Audit Trail</span>
          </div>
          <div className="p-2.5 rounded bg-emerald-50/70 border border-emerald-200 text-emerald-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Zero Unmasked Secrets Model Egress</span>
          </div>
        </div>
      </div>
    </div>
  );
};
