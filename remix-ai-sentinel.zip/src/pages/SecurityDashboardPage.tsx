import React, { useState } from 'react';
import { StreamlitMetric } from '../components/StreamlitMetric';
import { ShieldAlert, Activity, AlertTriangle, CheckCircle, Flame, Filter, Clock, ArrowUpRight } from 'lucide-react';

const CATEGORY_STATS = [
  { name: 'SSN & Govt Identifiers', count: 412, percentage: 33, color: 'bg-red-500', severity: 'Critical' },
  { name: 'Credit Cards & PCI-DSS', count: 289, percentage: 23, color: 'bg-rose-500', severity: 'Critical' },
  { name: 'API Secrets & Dev Tokens', count: 215, percentage: 17, color: 'bg-amber-500', severity: 'Critical' },
  { name: 'Emails & Contact Data', count: 680, percentage: 54, color: 'bg-blue-500', severity: 'Medium' },
  { name: 'HIPAA & Medical Records', count: 94, percentage: 8, color: 'bg-purple-500', severity: 'High' },
  { name: 'Internal IP / Hostnames', count: 142, percentage: 11, color: 'bg-emerald-500', severity: 'Low' },
];

const HOURLY_TRAFFIC = [
  { hour: '08:00', total: 420, blocked: 24 },
  { hour: '09:00', total: 680, blocked: 45 },
  { hour: '10:00', total: 950, blocked: 78 },
  { hour: '11:00', total: 1120, blocked: 92 },
  { hour: '12:00', total: 890, blocked: 58 },
  { hour: '13:00', total: 1040, blocked: 83 },
  { hour: '14:00', total: 1280, blocked: 109 },
  { hour: '15:00', total: 1410, blocked: 121 },
];

const RECENT_THREAT_ALERTS = [
  {
    id: 'ALT-109',
    time: '2 mins ago',
    title: 'High-Volume SSN Leakage Blocked',
    source: 'Support Copilot API',
    severity: 'CRITICAL',
    action: 'Auto-Masked & Notified SecOps'
  },
  {
    id: 'ALT-108',
    time: '8 mins ago',
    title: 'OpenAI Secret Token in Code Prompt',
    source: 'Dev Sandbox Proxy',
    severity: 'CRITICAL',
    action: 'Scrubbed Token'
  },
  {
    id: 'ALT-107',
    time: '24 mins ago',
    title: 'System Prompt Extraction Jailbreak',
    source: 'Public Web Assistant',
    severity: 'HIGH',
    action: 'Blocked & Session Flagged'
  },
  {
    id: 'ALT-106',
    time: '45 mins ago',
    title: 'Patient Medical Record Ingestion',
    source: 'Claims Analyzer',
    severity: 'HIGH',
    action: 'Masked HIPAA PHI'
  }
];

export const SecurityDashboardPage: React.FC = () => {
  const [filterSeverity, setFilterSeverity] = useState<string>('all');

  const filteredAlerts = filterSeverity === 'all'
    ? RECENT_THREAT_ALERTS
    : RECENT_THREAT_ALERTS.filter(a => a.severity.toLowerCase() === filterSeverity.toLowerCase());

  return (
    <div className="max-w-6xl mx-auto space-y-7 pb-12">
      {/* Title */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
          <span>📊</span>
          <span>Security & Threat Telemetry Dashboard</span>
        </h1>
        <p className="text-slate-600 text-sm mt-1.5">
          Real-time telemetry and risk metrics across all connected AI services and upstream gateways.
        </p>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StreamlitMetric
          id="metric-risk-index"
          label="Risk Threat Index"
          value="14 / 100"
          delta="-3.2 pts"
          isInverse={true}
          help="Normalized real-time security risk level (0=Safe, 100=Under Attack)"
        />
        <StreamlitMetric
          id="metric-total-interceptions"
          label="Total Interceptions"
          value="1,248"
          delta="+12.1%"
          isInverse={true}
          help="Total sensitive prompts intercepted and sanitized"
        />
        <StreamlitMetric
          id="metric-jailbreaks-blocked"
          label="Jailbreaks Neutralized"
          value="42"
          delta="+3 today"
          isInverse={true}
          help="Prompt injection and jailbreak payloads neutralized"
        />
        <StreamlitMetric
          id="metric-gateways-active"
          label="Protected Gateways"
          value="6 / 6"
          delta="100% Healthy"
          help="Active reverse proxy endpoints routing through AI Sentinel"
        />
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown */}
        <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#ff4b4b]" />
              <span>Interceptions by Category (st.bar_chart)</span>
            </h3>
            <span className="text-xs text-slate-500 font-medium">Last 24 Hours</span>
          </div>

          <div className="space-y-3.5 pt-1">
            {CATEGORY_STATS.map((cat) => (
              <div key={cat.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-medium">
                  <span className="text-slate-800 font-semibold">{cat.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900">{cat.count}</span>
                    <span className="text-slate-400">({cat.percentage}%)</span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className={`${cat.color} h-2 rounded-full transition-all duration-500`}
                    style={{ width: `${cat.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hourly Traffic and Block Distribution */}
        <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-600" />
              <span>Hourly Traffic & Block Rate</span>
            </h3>
            <span className="text-xs text-slate-500 font-medium">Prompts / Hour</span>
          </div>

          {/* Simple Clean Bar Chart Representation */}
          <div className="h-52 flex items-end justify-between gap-2 pt-4 px-2 border-b border-slate-100">
            {HOURLY_TRAFFIC.map((item) => {
              const heightPercent = Math.round((item.total / 1500) * 100);
              const blockedHeightPercent = Math.round((item.blocked / item.total) * 100 * 2.5);
              return (
                <div key={item.hour} className="flex-1 flex flex-col items-center gap-1.5 group relative">
                  {/* Tooltip */}
                  <div className="absolute -top-12 bg-slate-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-10 shadow-md">
                    Total: {item.total} | Blocked: {item.blocked}
                  </div>

                  <div className="w-full bg-slate-100 rounded-t flex flex-col justify-end overflow-hidden" style={{ height: `${heightPercent}%` }}>
                    <div className="w-full bg-blue-500/80 group-hover:bg-blue-600 transition-colors flex-1" />
                    <div className="w-full bg-red-500/90" style={{ height: `${Math.max(10, blockedHeightPercent)}%` }} />
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{item.hour}</span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-center gap-6 text-xs text-slate-600 pt-1">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-blue-500" />
              <span>Clean Traffic</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-red-500" />
              <span>Sanitized / Blocked</span>
            </div>
          </div>
        </div>
      </div>

      {/* Threat Radar Feed */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Flame className="w-4 h-4 text-red-600" />
              <span>Live Threat Radar & Incident Alerts</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Real-time alerts emitted by the AI Sentinel firewall</p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Filter:</span>
            <select
              value={filterSeverity}
              onChange={(e) => setFilterSeverity(e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded px-2.5 py-1 text-slate-700 font-medium outline-none"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical Only</option>
              <option value="high">High Only</option>
            </select>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {filteredAlerts.map((alert) => (
            <div key={alert.id} className="p-4 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors">
              <div className="flex items-start gap-3">
                <span
                  className={`mt-0.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    alert.severity === 'CRITICAL'
                      ? 'bg-red-100 text-red-700 border border-red-200'
                      : 'bg-amber-100 text-amber-800 border border-amber-200'
                  }`}
                >
                  {alert.severity}
                </span>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{alert.title}</h4>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-0.5">
                    <span>Source: {alert.source}</span>
                    <span>•</span>
                    <span>Action: {alert.action}</span>
                  </div>
                </div>
              </div>

              <span className="text-xs text-slate-400 whitespace-nowrap font-mono flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {alert.time}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
