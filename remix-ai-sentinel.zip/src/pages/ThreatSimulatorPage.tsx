import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  ShieldX,
  AlertTriangle,
  Play,
  Flame,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  RefreshCw,
  Terminal,
  Activity,
  Layers,
  FileText,
  Lock,
  Zap,
  Info,
  ChevronRight,
  Database,
  Sliders,
  Send
} from 'lucide-react';
import {
  AttackHistoryRecord,
  AttackScenario,
  AuditLogEntry,
  PageType,
  ScanResult,
  SentinelSettings,
  ThreatSimulatorScorecard
} from '../types';
import { ATTACK_SCENARIOS, INITIAL_ATTACK_HISTORY, INITIAL_SCORECARD } from '../data/mockData';
import { runPIIScan } from '../utils/piiEngine';

interface ThreatSimulatorPageProps {
  settings: SentinelSettings;
  onNavigate?: (page: PageType) => void;
  onAddAuditLog: (log: AuditLogEntry) => void;
}

export const ThreatSimulatorPage: React.FC<ThreatSimulatorPageProps> = ({
  settings,
  onNavigate,
  onAddAuditLog
}) => {
  const [selectedScenario, setSelectedScenario] = useState<AttackScenario>(ATTACK_SCENARIOS[0]);
  const [customPrompt, setCustomPrompt] = useState<string>(ATTACK_SCENARIOS[0].prompt);
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [activePipelineStep, setActivePipelineStep] = useState<number>(0);
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [modelResponse, setModelResponse] = useState<string | null>(null);
  const [scorecard, setScorecard] = useState<ThreatSimulatorScorecard>(INITIAL_SCORECARD);
  const [attackHistory, setAttackHistory] = useState<AttackHistoryRecord[]>(INITIAL_ATTACK_HISTORY);
  const [activeTab, setActiveTab] = useState<'pipeline' | 'why_explanation' | 'history'>('pipeline');
  const [lastAuditId, setLastAuditId] = useState<string | null>(null);

  const handleSelectScenario = (scenario: AttackScenario) => {
    setSelectedScenario(scenario);
    setCustomPrompt(scenario.prompt);
    setIsCustomMode(false);
    setCurrentResult(null);
    setModelResponse(null);
    setActivePipelineStep(0);
  };

  const handleRunAttackSimulation = async () => {
    setIsSimulating(true);
    setActivePipelineStep(1);
    setCurrentResult(null);
    setModelResponse(null);

    const promptToTest = customPrompt;

    // Step 1: Scan & Detect
    await new Promise((r) => setTimeout(r, 200));
    setActivePipelineStep(2); // Threat Classification
    
    await new Promise((r) => setTimeout(r, 250));
    setActivePipelineStep(3); // Risk Score & Policy Evaluation
    
    const scan = runPIIScan(promptToTest, settings);
    setCurrentResult(scan);

    await new Promise((r) => setTimeout(r, 300));
    setActivePipelineStep(4); // Sanitization & Redaction

    await new Promise((r) => setTimeout(r, 350));
    setActivePipelineStep(5); // AI Gateway Dispatch / Block Execution

    // Dispatch to Gemini or Block
    const auditId = `ATK-LOG-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setLastAuditId(auditId);

    const isBlocked = scan.decision.action === 'BLOCK';
    const isSanitized = scan.decision.action === 'SANITIZE_AND_SEND';

    if (isBlocked) {
      setModelResponse(
        `[SECURITY GATEWAY BLOCKED]\nExecution aborted. The prompt was denied egress to downstream Gemini models because it violated active Zero-Trust security rules (${scan.decision.blockedCategories.join(', ')}).\n\nReason: ${scan.decision.reason}`
      );
    } else {
      // Safe sanitized prompt dispatched
      try {
        const res = await fetch('/api/gemini/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sanitizedPrompt: scan.redactedText })
        });
        if (res.ok) {
          const data = await res.json();
          setModelResponse(data.text || 'Simulated Model Response generated successfully.');
        } else {
          setModelResponse(`[Simulated Safe Model Response]: Processed prompt safely with sanitized tokens (${scan.detectedEntities.length} sanitized). Output generated without exposing sensitive user PII.`);
        }
      } catch {
        setModelResponse(`[AI Gateway Simulated Response]: Safely processed sanitized prompt without leaking sensitive identity tokens. Compliance rules satisfied.`);
      }
    }

    // Step 6: Create Audit Log Entry
    const auditLog: AuditLogEntry = {
      id: auditId,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      eventType: isBlocked ? 'THREAT_SIMULATION_BLOCKED' : 'THREAT_SIMULATION_SANITIZED',
      severity: scan.threatClassification.severity,
      sourceApp: 'AI Threat Simulator',
      userId: 'red_team_tester',
      ipAddress: '10.240.12.99',
      details: isBlocked
        ? `Threat blocked: ${scan.threatClassification.categoryLabel} [${scan.decision.blockedCategories.join(', ')}] with Risk Score ${scan.riskScore}/100.`
        : `Threat sanitized: Scrubbed ${scan.detectedEntities.length} token(s) before model dispatch. Risk Score ${scan.riskScore}/100.`,
      status: isBlocked ? 'BLOCKED' : 'SANITIZED',
      latencyMs: scan.scanDurationMs + 8.5,
      detectedCategories: Array.from(new Set(scan.detectedEntities.map(e => e.type))),
      riskScore: scan.riskScore,
      policyAction: scan.decision.action
    };

    onAddAuditLog(auditLog);

    // Update History Record (safe metadata only)
    const newHistoryRecord: AttackHistoryRecord = {
      id: auditId,
      timestamp: new Date().toLocaleTimeString(),
      attackType: isCustomMode ? 'Custom Red-Team Payload' : selectedScenario.name,
      riskScore: scan.riskScore,
      riskLevel: scan.threatClassification.severity,
      detectedData: Array.from(new Set(scan.detectedEntities.map(e => e.type))),
      decision: isBlocked ? 'BLOCK' : isSanitized ? 'MASK' : 'ALLOW',
      status: isBlocked ? 'BLOCKED' : isSanitized ? 'SANITIZED' : 'ALLOWED',
      latencyMs: scan.scanDurationMs,
      summary: isBlocked ? scan.decision.reason : `Sanitized ${scan.detectedEntities.length} entity tokens.`
    };

    setAttackHistory((prev) => [newHistoryRecord, ...prev.slice(0, 19)]);

    // Update Scorecard
    setScorecard((prev) => ({
      attacksSimulated: prev.attacksSimulated + 1,
      threatsDetected: prev.threatsDetected + scan.detectedEntities.length,
      threatsBlocked: prev.threatsBlocked + (isBlocked ? 1 : 0),
      threatsSanitized: prev.threatsSanitized + (isSanitized ? 1 : 0),
      averageRiskScore: Math.round((prev.averageRiskScore * prev.attacksSimulated + scan.riskScore) / (prev.attacksSimulated + 1)),
      sensitiveEntitiesDetected: prev.sensitiveEntitiesDetected + scan.detectedEntities.length
    }));

    setActivePipelineStep(6); // Done
    setIsSimulating(false);
  };

  const getSeverityBadgeClass = (sev: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL') => {
    switch (sev) {
      case 'CRITICAL':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'HIGH':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'MEDIUM':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'LOW':
      default:
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Educational Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-indigo-900/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 border border-red-400/30 text-red-300 text-xs font-semibold uppercase tracking-wider">
              <Flame className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              <span>Phase 3 — Interactive Red-Team Threat Lab</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center gap-3">
              <ShieldAlert className="w-8 h-8 text-red-400" />
              <span>AI Threat Simulator & Intelligent Policy Engine</span>
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
              <strong>AI Sentinel</strong> acts as a zero-trust security gateway between users and generative AI models. It detects sensitive data, credential leaks, and malicious prompt injections before any request reaches the model.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => onNavigate?.('ai_playground')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-all border border-white/20 flex items-center gap-1.5 shadow-sm"
            >
              <span>AI Playground</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigate?.('settings')}
              className="px-4 py-2.5 rounded-xl bg-red-500/80 hover:bg-red-500 text-white text-xs font-semibold transition-all border border-red-400/40 flex items-center gap-1.5 shadow-sm"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Policy Config</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Security Scorecard */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Attacks Simulated</span>
            <Activity className="w-3.5 h-3.5 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{scorecard.attacksSimulated}</div>
          <div className="text-[11px] text-slate-400 mt-1">Live benchmark</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Threats Detected</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-600">{scorecard.threatsDetected}</div>
          <div className="text-[11px] text-amber-600/80 mt-1">Total vectors found</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Threats Blocked</span>
            <ShieldX className="w-3.5 h-3.5 text-red-500" />
          </div>
          <div className="text-2xl font-bold text-red-600">{scorecard.threatsBlocked}</div>
          <div className="text-[11px] text-red-500 font-medium mt-1">Egress denied</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Threats Sanitized</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-600">{scorecard.threatsSanitized}</div>
          <div className="text-[11px] text-emerald-600/80 mt-1">Safe model dispatch</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Avg. Risk Score</span>
            <Flame className="w-3.5 h-3.5 text-purple-500" />
          </div>
          <div className="text-2xl font-bold text-purple-700">{scorecard.averageRiskScore}<span className="text-xs font-normal text-slate-400">/100</span></div>
          <div className="text-[11px] text-purple-600/80 mt-1">Weighted metric</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <span>Entities Detected</span>
            <Database className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-blue-600">{scorecard.sensitiveEntitiesDetected}</div>
          <div className="text-[11px] text-blue-600/80 mt-1">PII & Secret tokens</div>
        </div>
      </div>

      {/* 3. Main Simulator Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Ready-Made Attack Scenarios (4 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Flame className="w-4 h-4 text-red-500" />
                <span>Ready-Made Attack Scenarios</span>
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                {ATTACK_SCENARIOS.length} Presets
              </span>
            </div>

            <div className="space-y-2.5">
              {ATTACK_SCENARIOS.map((sc) => {
                const isSelected = !isCustomMode && selectedScenario.id === sc.id;
                return (
                  <button
                    key={sc.id}
                    onClick={() => handleSelectScenario(sc)}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'border-red-500 bg-red-50/40 ring-2 ring-red-500/20 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-2xl p-1 bg-white rounded-lg border border-slate-100 shadow-2xs shrink-0">
                      {sc.iconEmoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-xs font-bold text-slate-900 truncate">
                          {sc.code}. {sc.name}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${getSeverityBadgeClass(sc.severityLevel)}`}>
                          {sc.severityLevel}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                        {sc.description}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {sc.expectedThreats.map((th, idx) => (
                          <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                            {th}
                          </span>
                        ))}
                      </div>
                    </div>
                  </button>
                );
              })}

              {/* Custom Red-Team Attack Box */}
              <button
                onClick={() => {
                  setIsCustomMode(true);
                  setCurrentResult(null);
                  setModelResponse(null);
                  setActivePipelineStep(0);
                }}
                className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                  isCustomMode
                    ? 'border-purple-500 bg-purple-50/40 ring-2 ring-purple-500/20 shadow-sm'
                    : 'border-dashed border-slate-300 hover:border-slate-400 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="text-2xl p-1 bg-white rounded-lg border border-slate-100 shadow-2xs shrink-0">
                  🧪
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-bold text-slate-900">
                      Custom Red-Team Attack Payload
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded border bg-purple-100 text-purple-700 border-purple-200">
                      CUSTOM
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Write arbitrary adversarial prompts, jailbreaks, or compound PII payloads to test gateway defense.
                  </p>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Execution Workspace & Live Pipeline (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Target Attack Scenario
                </span>
                <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
                  <span>{isCustomMode ? '🧪 Custom Red-Team Attack Tester' : `${selectedScenario.code}. ${selectedScenario.name}`}</span>
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-medium">
                  {isCustomMode ? 'Custom Payload' : selectedScenario.categoryLabel}
                </span>
              </div>
            </div>

            {/* Attack Input Prompt Textarea */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-slate-500" />
                  <span>Attack Prompt Payload (Input)</span>
                </label>
                <span className="text-[11px] text-slate-400">
                  Simulating adversarial prompt injection or PII egress
                </span>
              </div>
              <textarea
                value={customPrompt}
                onChange={(e) => {
                  setCustomPrompt(e.target.value);
                  setIsCustomMode(true);
                }}
                rows={4}
                className="w-full text-xs sm:text-sm font-mono p-3.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-red-500/20 focus:border-red-500 bg-slate-50 text-slate-900 leading-relaxed shadow-inner"
                placeholder="Enter adversarial prompt or sensitive customer data..."
              />
            </div>

            {/* Run Simulation Action Button */}
            <div className="flex items-center justify-between gap-4 pt-2">
              <button
                onClick={handleRunAttackSimulation}
                disabled={isSimulating || !customPrompt.trim()}
                className="flex-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-red-600 via-red-500 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-bold text-sm shadow-md shadow-red-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {isSimulating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Executing Zero-Trust Pipeline ({activePipelineStep}/6)...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>Run Attack Simulation</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  if (isCustomMode) setCustomPrompt('');
                  else setCustomPrompt(selectedScenario.prompt);
                  setCurrentResult(null);
                  setModelResponse(null);
                  setActivePipelineStep(0);
                }}
                className="px-4 py-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-all"
              >
                Reset
              </button>
            </div>

            {/* 4. Complete Security Pipeline Visualizer */}
            <div className="pt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
                <span>Zero-Trust Security Pipeline</span>
                <span className="text-[11px] font-normal text-slate-500">Full Gateway Traversal</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                {/* Step 1 */}
                <div
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activePipelineStep >= 1
                      ? 'border-indigo-500 bg-indigo-50/60 text-indigo-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-400'
                  }`}
                >
                  <div className="text-[10px] font-bold tracking-wider uppercase text-slate-500 mb-1">Step 1</div>
                  <div className="text-xs font-bold flex items-center justify-center gap-1">
                    <Terminal className="w-3.5 h-3.5" />
                    <span>Attack Input</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Intercept prompt</div>
                </div>

                {/* Step 2 */}
                <div
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activePipelineStep >= 2
                      ? 'border-amber-500 bg-amber-50/60 text-amber-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-400'
                  }`}
                >
                  <div className="text-[10px] font-bold tracking-wider uppercase text-slate-500 mb-1">Step 2</div>
                  <div className="text-xs font-bold flex items-center justify-center gap-1">
                    <Shield className="w-3.5 h-3.5" />
                    <span>PII & Secrets</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Token scanner</div>
                </div>

                {/* Step 3 */}
                <div
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activePipelineStep >= 3
                      ? 'border-purple-500 bg-purple-50/60 text-purple-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-400'
                  }`}
                >
                  <div className="text-[10px] font-bold tracking-wider uppercase text-slate-500 mb-1">Step 3</div>
                  <div className="text-xs font-bold flex items-center justify-center gap-1">
                    <Flame className="w-3.5 h-3.5" />
                    <span>Threat Class</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Risk 0–100</div>
                </div>

                {/* Step 4 */}
                <div
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activePipelineStep >= 4
                      ? 'border-blue-500 bg-blue-50/60 text-blue-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-400'
                  }`}
                >
                  <div className="text-[10px] font-bold tracking-wider uppercase text-slate-500 mb-1">Step 4</div>
                  <div className="text-xs font-bold flex items-center justify-center gap-1">
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Policy Action</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Block vs Mask</div>
                </div>

                {/* Step 5 */}
                <div
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activePipelineStep >= 5
                      ? currentResult?.decision.action === 'BLOCK'
                        ? 'border-red-500 bg-red-50/60 text-red-900 shadow-xs'
                        : 'border-emerald-500 bg-emerald-50/60 text-emerald-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-400'
                  }`}
                >
                  <div className="text-[10px] font-bold tracking-wider uppercase text-slate-500 mb-1">Step 5</div>
                  <div className="text-xs font-bold flex items-center justify-center gap-1">
                    <Zap className="w-3.5 h-3.5" />
                    <span>{currentResult?.decision.action === 'BLOCK' ? 'Blocked' : 'Sanitized'}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Egress filter</div>
                </div>

                {/* Step 6 */}
                <div
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    activePipelineStep >= 6
                      ? 'border-emerald-500 bg-emerald-50/60 text-emerald-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-400'
                  }`}
                >
                  <div className="text-[10px] font-bold tracking-wider uppercase text-slate-500 mb-1">Step 6</div>
                  <div className="text-xs font-bold flex items-center justify-center gap-1">
                    <FileText className="w-3.5 h-3.5" />
                    <span>Audit Event</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Immutable log</div>
                </div>
              </div>
            </div>
          </div>

          {/* Result View Tabs */}
          {currentResult && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="flex border-b border-slate-200 bg-slate-50/80 px-4 pt-3">
                <button
                  onClick={() => setActiveTab('pipeline')}
                  className={`px-4 py-2 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                    activeTab === 'pipeline'
                      ? 'border-red-500 text-red-600 bg-white rounded-t-lg'
                      : 'border-transparent text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Pipeline Analysis & Output</span>
                </button>
                <button
                  onClick={() => setActiveTab('why_explanation')}
                  className={`px-4 py-2 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                    activeTab === 'why_explanation'
                      ? 'border-red-500 text-red-600 bg-white rounded-t-lg'
                      : 'border-transparent text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Why was this {currentResult.decision.action === 'BLOCK' ? 'Blocked' : 'Sanitized'}?</span>
                </button>
                <button
                  onClick={() => setActiveTab('history')}
                  className={`px-4 py-2 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                    activeTab === 'history'
                      ? 'border-red-500 text-red-600 bg-white rounded-t-lg'
                      : 'border-transparent text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Attack History ({attackHistory.length})</span>
                </button>
              </div>

              <div className="p-5 sm:p-6 space-y-6">
                {/* TAB 1: PIPELINE ANALYSIS */}
                {activeTab === 'pipeline' && (
                  <div className="space-y-6">
                    {/* Risk & Classification Badges */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Classification Card */}
                      <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Threat Classification
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getSeverityBadgeClass(currentResult.threatClassification.severity)}`}>
                            {currentResult.threatClassification.severity}
                          </span>
                        </div>
                        <div className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                          <ShieldAlert className="w-4 h-4 text-red-500" />
                          <span>{currentResult.threatClassification.categoryLabel}</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {currentResult.threatClassification.explanation}
                        </p>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {currentResult.detectedEntities.map((ent, idx) => (
                            <span key={idx} className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-100 text-red-700 border border-red-200 font-semibold">
                              {ent.type}: {ent.value.length > 20 ? `${ent.value.slice(0, 20)}...` : ent.value}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Visual Risk Gauge Card */}
                      <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Risk Severity Score
                          </span>
                          <span className="text-xs font-mono font-bold text-slate-700">
                            {currentResult.scanDurationMs}ms latency
                          </span>
                        </div>

                        <div className="flex items-end gap-3">
                          <div className={`text-4xl font-extrabold tracking-tight ${
                            currentResult.riskScore >= 80 ? 'text-red-600' : currentResult.riskScore >= 50 ? 'text-amber-600' : 'text-emerald-600'
                          }`}>
                            {currentResult.riskScore}
                            <span className="text-sm font-semibold text-slate-400">/100</span>
                          </div>
                          <div className="pb-1.5">
                            <span className={`text-xs font-bold px-2.5 py-1 rounded-md border uppercase ${getSeverityBadgeClass(currentResult.threatClassification.severity)}`}>
                              {currentResult.threatClassification.severity} RISK
                            </span>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              currentResult.riskScore >= 80
                                ? 'bg-red-500'
                                : currentResult.riskScore >= 50
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.max(5, currentResult.riskScore)}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] font-semibold text-slate-400">
                          <span>0 Safe</span>
                          <span>25 Low</span>
                          <span>50 Medium</span>
                          <span>75 High</span>
                          <span>100 Critical</span>
                        </div>
                      </div>
                    </div>

                    {/* Policy Gate Decision Notice */}
                    <div className={`p-4 rounded-xl border flex items-start gap-3.5 ${
                      currentResult.decision.action === 'BLOCK'
                        ? 'bg-red-50 border-red-200 text-red-900'
                        : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    }`}>
                      {currentResult.decision.action === 'BLOCK' ? (
                        <ShieldX className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                      ) : (
                        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      )}
                      <div className="space-y-1">
                        <div className="text-xs font-bold uppercase tracking-wider">
                          Policy Enforcement: {currentResult.decision.action}
                        </div>
                        <p className="text-xs sm:text-sm leading-relaxed">
                          {currentResult.decision.reason}
                        </p>
                      </div>
                    </div>

                    {/* Side-by-Side: Sanitized Payload & Model Response */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Sanitized Prompt */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Sanitized Prompt (Outbound)</span>
                          </span>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                            Zero Raw Sensitive Egress
                          </span>
                        </div>
                        <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 font-mono text-xs text-slate-800 h-40 overflow-y-auto leading-relaxed whitespace-pre-wrap">
                          {currentResult.redactedText}
                        </div>
                      </div>

                      {/* AI Model Output / Block Confirmation */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                            <Zap className="w-3.5 h-3.5 text-indigo-600" />
                            <span>AI Model Response / Egress Gate</span>
                          </span>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                            currentResult.decision.action === 'BLOCK' ? 'bg-red-100 text-red-800' : 'bg-indigo-100 text-indigo-800'
                          }`}>
                            {currentResult.decision.action === 'BLOCK' ? 'Prompt Blocked' : 'Gemini 3.7 Flash'}
                          </span>
                        </div>
                        <div className={`p-3.5 rounded-xl border font-mono text-xs h-40 overflow-y-auto leading-relaxed whitespace-pre-wrap ${
                          currentResult.decision.action === 'BLOCK'
                            ? 'bg-red-50/80 border-red-200 text-red-800'
                            : 'bg-slate-900 border-slate-800 text-emerald-400'
                        }`}>
                          {modelResponse || 'Awaiting response...'}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 2: WHY WAS THIS BLOCKED / SANITIZED? */}
                {activeTab === 'why_explanation' && (
                  <div className="space-y-6">
                    <div className="p-6 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-5">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                        <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
                          <Info className="w-4 h-4 text-red-500" />
                          <span>Forensic Policy Gate Explanation</span>
                        </h4>
                        <span className={`text-xs font-bold px-2.5 py-1 rounded-md border uppercase ${
                          currentResult.decision.action === 'BLOCK'
                            ? 'bg-red-100 text-red-700 border-red-200'
                            : 'bg-emerald-100 text-emerald-700 border-emerald-200'
                        }`}>
                          {currentResult.decision.action}
                        </span>
                      </div>

                      {/* Structured Why Card as specified in Prompt */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-1">
                          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Threat Classified
                          </div>
                          <div className="text-sm font-extrabold text-slate-900">
                            {currentResult.threatClassification.categoryLabel}
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-1">
                          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Risk Severity
                          </div>
                          <div className={`text-sm font-extrabold ${
                            currentResult.riskScore >= 80 ? 'text-red-600' : 'text-amber-600'
                          }`}>
                            {currentResult.riskScore}/100 — {currentResult.threatClassification.severity}
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-1">
                          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Detected Vectors
                          </div>
                          <div className="text-xs font-mono font-bold text-slate-800">
                            {currentResult.detectedEntities.map(e => e.type).join(', ') || 'None'}
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-1">
                          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Enforced Policy Rule
                          </div>
                          <div className="text-xs font-bold text-slate-800">
                            {currentResult.decision.action} ({settings.environment.toUpperCase()} ENV)
                          </div>
                        </div>
                      </div>

                      <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-2">
                        <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                          Policy Enforcement Reason & Regulatory Grounding
                        </div>
                        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
                          {currentResult.decision.whyExplanation?.reason || currentResult.decision.reason}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <span className="text-xs text-slate-500">
                          Audit Trail Recorded: <strong className="font-mono text-slate-700">{lastAuditId}</strong>
                        </span>
                        <button
                          onClick={() => onNavigate?.('audit_logs')}
                          className="text-xs font-bold text-red-600 hover:underline flex items-center gap-1"
                        >
                          <span>Inspect in Audit Logs</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 3: ATTACK HISTORY */}
                {activeTab === 'history' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                        Simulated Attack History Log
                      </h4>
                      <span className="text-[11px] text-slate-500">
                        Sanitized safe metadata only (no raw PII stored)
                      </span>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                            <th className="p-3">Time</th>
                            <th className="p-3">Attack Type</th>
                            <th className="p-3">Risk Score</th>
                            <th className="p-3">Detected Data</th>
                            <th className="p-3">Decision</th>
                            <th className="p-3">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {attackHistory.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-3 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                                {item.timestamp}
                              </td>
                              <td className="p-3 font-bold text-slate-900">
                                {item.attackType}
                              </td>
                              <td className="p-3">
                                <span className={`font-bold font-mono px-2 py-0.5 rounded text-[11px] ${
                                  item.riskScore >= 80 ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                                }`}>
                                  {item.riskScore}/100
                                </span>
                              </td>
                              <td className="p-3">
                                <div className="flex flex-wrap gap-1">
                                  {item.detectedData.map((d, i) => (
                                    <span key={i} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                                      {d}
                                    </span>
                                  ))}
                                </div>
                              </td>
                              <td className="p-3 font-bold">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                                  item.decision === 'BLOCK' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                                }`}>
                                  {item.decision}
                                </span>
                              </td>
                              <td className="p-3">
                                <span className={`inline-flex items-center gap-1 text-[11px] font-bold ${
                                  item.status === 'BLOCKED' ? 'text-red-600' : 'text-emerald-600'
                                }`}>
                                  {item.status === 'BLOCKED' ? (
                                    <XCircle className="w-3.5 h-3.5" />
                                  ) : (
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                  )}
                                  <span>{item.status}</span>
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
