import React, { useState, useEffect } from 'react';
import { SentinelSettings, ScanResult, GeminiGatewayResponse, AuditLogEntry, PageType } from '../types';
import { runPIIScan } from '../utils/piiEngine';
import { SAMPLE_PROMPTS } from '../data/mockData';
import { StreamlitMetric } from '../components/StreamlitMetric';
import { StInfo, StSuccess, StWarning, StError } from '../components/StreamlitCallouts';
import { 
  Sparkles, 
  Shield, 
  ShieldAlert, 
  ShieldCheck, 
  Lock, 
  Send, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Eye, 
  EyeOff, 
  Bot, 
  Copy, 
  Check, 
  RotateCcw, 
  Zap, 
  FileText, 
  Settings as SettingsIcon,
  HelpCircle,
  ExternalLink,
  Cpu,
  Layers,
  ArrowDown
} from 'lucide-react';

interface AIPlaygroundPageProps {
  settings: SentinelSettings;
  onNavigate?: (page: PageType) => void;
  onAddAuditLog: (log: AuditLogEntry) => void;
}

export const AIPlaygroundPage: React.FC<AIPlaygroundPageProps> = ({
  settings,
  onNavigate,
  onAddAuditLog
}) => {
  // State
  const [promptText, setPromptText] = useState<string>(SAMPLE_PROMPTS[0].text);
  const [selectedPresetId, setSelectedPresetId] = useState<string>(SAMPLE_PROMPTS[0].id);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [geminiResponse, setGeminiResponse] = useState<GeminiGatewayResponse | null>(null);
  const [activeStep, setActiveStep] = useState<'input' | 'scanned' | 'sent' | 'responded'>('input');
  const [copiedResponse, setCopiedResponse] = useState<boolean>(false);
  const [copiedSanitized, setCopiedSanitized] = useState<boolean>(false);
  const [lastAuditId, setLastAuditId] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState<{ isConfigured: boolean; mode: string } | null>(null);

  // Check API status on mount
  useEffect(() => {
    fetch('/api/gemini/status')
      .then(res => res.json())
      .then(data => setApiStatus(data))
      .catch(() => setApiStatus({ isConfigured: false, mode: 'SIMULATION_FALLBACK' }));
  }, []);

  // Handle Preset Selection
  const handleSelectPreset = (id: string) => {
    setSelectedPresetId(id);
    const sample = SAMPLE_PROMPTS.find(p => p.id === id);
    if (sample) {
      setPromptText(sample.text);
      setScanResult(null);
      setGeminiResponse(null);
      setActiveStep('input');
      setLastAuditId(null);
    }
  };

  // 1. Scan & Protect
  const handleScanAndProtect = () => {
    if (!promptText.trim()) return;
    setIsScanning(true);
    
    setTimeout(() => {
      const result = runPIIScan(promptText, settings);
      setScanResult(result);
      setIsScanning(false);
      setActiveStep('scanned');
      setGeminiResponse(null);
    }, 150);
  };

  // 2. Send Secure Prompt to Gemini
  const handleSendToGemini = async () => {
    let currentResult = scanResult;
    if (!currentResult) {
      currentResult = runPIIScan(promptText, settings);
      setScanResult(currentResult);
    }

    if (currentResult.decision.action === 'BLOCK') {
      // Record Blocked Audit Log
      const auditLogId = `LOG-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const newLog: AuditLogEntry = {
        id: auditLogId,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        eventType: 'POLICY_VIOLATION',
        severity: 'CRITICAL',
        sourceApp: 'AI Playground (Egress Firewall)',
        userId: 'usr_secops_demo',
        ipAddress: '127.0.0.1',
        details: `Egress BLOCKED: Forbidden ${currentResult.decision.blockedCategories.join(', ')} detected in prompt.`,
        status: 'BLOCKED',
        latencyMs: currentResult.scanDurationMs,
        detectedCategories: currentResult.decision.blockedCategories,
        riskScore: currentResult.riskScore,
        policyAction: 'BLOCK'
      };
      onAddAuditLog(newLog);
      setLastAuditId(auditLogId);
      return;
    }

    setIsGenerating(true);
    setActiveStep('sent');

    try {
      const response = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sanitizedPrompt: currentResult.redactedText,
          originalPromptLength: promptText.length,
          detectedEntitiesCount: currentResult.detectedEntities.length
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data: GeminiGatewayResponse = await response.json();
      setGeminiResponse(data);
      setActiveStep('responded');

      // Create Audit Log Entry for Protected Dispatch
      const auditLogId = `LOG-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const entityTypes: string[] = Array.from(new Set(currentResult.detectedEntities.map(e => e.type)));
      
      const newLog: AuditLogEntry = {
        id: auditLogId,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        eventType: entityTypes.length > 0 ? 'SECURE_LLM_DISPATCH' : 'AUTHENTICATION',
        severity: currentResult.riskScore > 60 ? 'HIGH' : currentResult.riskScore > 25 ? 'MEDIUM' : 'LOW',
        sourceApp: 'AI Playground (Gemini Gateway)',
        userId: 'usr_secops_demo',
        ipAddress: '127.0.0.1',
        details: entityTypes.length > 0
          ? `Sanitized ${entityTypes.join(', ')} before proxying to Gemini 3.7 Flash.`
          : 'Clean prompt verified and dispatched to Gemini 3.7 Flash.',
        status: entityTypes.length > 0 ? 'SANITIZED' : 'RESOLVED',
        latencyMs: Math.round(currentResult.scanDurationMs + data.latencyMs),
        detectedCategories: entityTypes,
        riskScore: currentResult.riskScore,
        policyAction: currentResult.decision.action
      };

      onAddAuditLog(newLog);
      setLastAuditId(auditLogId);
    } catch (err) {
      console.error('Failed to send prompt to Gemini gateway:', err);
      // Fallback
      setGeminiResponse({
        text: `### AI Model Response (Safe Simulation)\n\nThank you for reaching out! I have received your inquiry. All customer identity tokens and sensitive credentials were sanitized by AI Sentinel prior to processing.\n\n*Sanitized Input Received:* "${currentResult.redactedText}"`,
        model: 'gemini-3.7-flash (Offline Fallback)',
        mode: 'simulation',
        latencyMs: 140,
        notice: 'Network or key issue. Operating in offline simulation mode.'
      });
      setActiveStep('responded');
    } finally {
      setIsGenerating(false);
    }
  };

  // 1-Click Scan, Protect & Send
  const handleOneClickExecute = () => {
    const result = runPIIScan(promptText, settings);
    setScanResult(result);
    if (result.decision.action !== 'BLOCK') {
      setTimeout(() => {
        handleSendToGemini();
      }, 100);
    }
  };

  const copyToClipboard = (text: string, type: 'response' | 'sanitized') => {
    navigator.clipboard.writeText(text);
    if (type === 'response') {
      setCopiedResponse(true);
      setTimeout(() => setCopiedResponse(false), 2000);
    } else {
      setCopiedSanitized(true);
      setTimeout(() => setCopiedSanitized(false), 2000);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Streamlit Title */}
      <div className="border-b border-slate-200 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <span>✨</span>
            <span>AI Playground: Live Protected Gemini Gateway</span>
          </h1>
          <p className="text-slate-600 text-sm mt-1.5 leading-relaxed">
            Zero-trust AI firewall intercepts and sanitizes sensitive data <strong>BEFORE</strong> prompts reach Gemini.
          </p>
        </div>

        {/* API Status Pill */}
        <div className="flex items-center gap-2">
          {apiStatus?.isConfigured ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Gemini API: Live (Cloud)</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>Gemini API: Demo Mode (Safe Simulation)</span>
            </div>
          )}
        </div>
      </div>

      {/* Security Pipeline Flow Visualizer */}
      <div className="bg-slate-900 text-white rounded-xl p-4 sm:p-5 border border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-3 text-xs font-semibold text-slate-300">
          <div className="flex items-center gap-1.5 text-red-400 font-bold uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" />
            <span>Zero-Trust Security Flow Pipeline</span>
          </div>
          <span className="text-[11px] font-mono text-slate-400">Target Model: gemini-3.7-flash</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 items-center text-center">
          {/* Step 1 */}
          <div className={`p-2.5 rounded-lg border text-xs font-medium transition-all ${
            activeStep === 'input' ? 'bg-blue-950/80 border-blue-500 text-blue-200' : 'bg-slate-800/80 border-slate-700 text-slate-300'
          }`}>
            <span className="text-[10px] block uppercase text-slate-400 font-bold">Step 1</span>
            <span className="font-bold text-slate-100">User Prompt</span>
          </div>

          <div className="hidden lg:flex items-center justify-center text-slate-500">
            <ArrowRight className="w-4 h-4" />
          </div>

          {/* Step 2 */}
          <div className={`p-2.5 rounded-lg border text-xs font-medium transition-all ${
            activeStep === 'scanned' || scanResult ? 'bg-purple-950/80 border-purple-500 text-purple-200' : 'bg-slate-800/80 border-slate-700 text-slate-300'
          }`}>
            <span className="text-[10px] block uppercase text-slate-400 font-bold">Step 2</span>
            <span className="font-bold text-slate-100">PII & Secret Scan</span>
          </div>

          <div className="hidden lg:flex items-center justify-center text-slate-500">
            <ArrowRight className="w-4 h-4" />
          </div>

          {/* Step 3 */}
          <div className={`p-2.5 rounded-lg border text-xs font-medium transition-all ${
            scanResult?.decision.action === 'BLOCK'
              ? 'bg-red-950/90 border-red-500 text-red-200'
              : scanResult ? 'bg-amber-950/80 border-amber-500 text-amber-200' : 'bg-slate-800/80 border-slate-700 text-slate-300'
          }`}>
            <span className="text-[10px] block uppercase text-slate-400 font-bold">Step 3</span>
            <span className="font-bold text-slate-100">
              {scanResult?.decision.action === 'BLOCK' ? 'Policy Block 🛑' : 'Policy Sanitization 🛡️'}
            </span>
          </div>

          <div className="hidden lg:flex items-center justify-center text-slate-500">
            <ArrowRight className="w-4 h-4" />
          </div>

          {/* Step 4 */}
          <div className={`p-2.5 rounded-lg border text-xs font-medium transition-all ${
            geminiResponse ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200' : 'bg-slate-800/80 border-slate-700 text-slate-300'
          }`}>
            <span className="text-[10px] block uppercase text-slate-400 font-bold">Step 4</span>
            <span className="font-bold text-slate-100">Gemini Response 🤖</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Column (Input & Presets) / Right Column (Security Gate & Actions) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: 7 Cols */}
        <div className="lg:col-span-7 space-y-5">
          {/* Preset Selector */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs space-y-2.5">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
              <span>Select Demonstration Scenario:</span>
              <span className="text-[11px] font-normal text-slate-500 font-sans">Quick-fill test cases</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SAMPLE_PROMPTS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset.id)}
                  className={`text-left p-2.5 rounded-md border text-xs transition-all ${
                    selectedPresetId === preset.id
                      ? 'bg-red-50/70 border-[#ff4b4b] text-slate-900 font-medium ring-1 ring-[#ff4b4b]'
                      : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <div className="font-semibold text-slate-900 truncate">{preset.title}</div>
                  <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{preset.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Prompt Text Area */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <label htmlFor="input-prompt-textarea" className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <span>User Prompt / AI Payload</span>
                <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono text-[10px]">
                  {promptText.length} chars
                </span>
              </label>
              
              <button
                onClick={() => {
                  setPromptText('');
                  setScanResult(null);
                  setGeminiResponse(null);
                  setActiveStep('input');
                }}
                className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1 transition-colors"
                title="Clear input"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Clear</span>
              </button>
            </div>

            <textarea
              id="input-prompt-textarea"
              value={promptText}
              onChange={(e) => {
                setPromptText(e.target.value);
                setScanResult(null);
                setGeminiResponse(null);
                setActiveStep('input');
              }}
              placeholder="Enter your prompt here (e.g. including emails, phone numbers, secret API keys, PAN/Aadhaar IDs to test firewall protection)..."
              rows={6}
              className="w-full p-3 font-mono text-xs text-slate-800 bg-slate-50/50 border border-slate-300 rounded-md focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#ff4b4b]/30 focus:border-[#ff4b4b] transition-all resize-y leading-relaxed"
            />

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
              <button
                id="btn-scan-and-protect"
                onClick={handleScanAndProtect}
                disabled={isScanning || !promptText.trim()}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-[#ff4b4b] hover:bg-[#e03a3a] disabled:opacity-50 text-white text-xs font-bold rounded-md transition-colors shadow-xs"
              >
                <Shield className="w-4 h-4" />
                <span>{isScanning ? 'Scanning Prompt...' : '1. Scan & Protect'}</span>
              </button>

              <button
                id="btn-one-click-execute"
                onClick={handleOneClickExecute}
                disabled={isGenerating || !promptText.trim()}
                className="flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold rounded-md transition-colors shadow-xs"
              >
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Scan, Protect & Send ⚡</span>
              </button>
            </div>
          </div>

          {/* Sanitized Prompt Egress Preview (Crucial Feature) */}
          {scanResult && (
            <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-emerald-600" />
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Sanitized Payload for Gemini Egress
                  </h3>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Zero Raw PII Leaked</span>
                  </span>
                  
                  <button
                    id="btn-copy-sanitized"
                    onClick={() => copyToClipboard(scanResult.redactedText, 'sanitized')}
                    className="p-1 text-slate-500 hover:text-slate-700 rounded transition-colors"
                    title="Copy Sanitized Prompt"
                  >
                    {copiedSanitized ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="bg-slate-900 text-emerald-400 font-mono text-xs p-3.5 rounded-md border border-slate-800 leading-relaxed overflow-x-auto selection:bg-emerald-800">
                {scanResult.redactedText || <span className="text-slate-500 italic">Empty payload</span>}
              </div>

              {scanResult.decision.action === 'BLOCK' ? (
                <div className="p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-800 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-red-600" />
                    <span>EGRESS BLOCKED BY ZERO-TRUST POLICY</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    {scanResult.decision.reason}
                  </p>
                  <p className="text-[11px] text-red-700 pt-1">
                    To allow sanitized dispatch for these entity types, adjust your rule to <strong>REDACT</strong> in{' '}
                    <button onClick={() => onNavigate?.('settings')} className="underline font-bold hover:text-red-900">
                      Settings
                    </button>.
                  </p>
                </div>
              ) : (
                <button
                  id="btn-send-to-gemini"
                  onClick={handleSendToGemini}
                  disabled={isGenerating || !scanResult.redactedText.trim()}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-md transition-colors shadow-xs"
                >
                  {isGenerating ? (
                    <>
                      <Cpu className="w-4 h-4 animate-spin" />
                      <span>Sending Sanitized Prompt to Gemini 3.7 Flash...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>2. Send Secure Prompt to Gemini</span>
                    </>
                  )}
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right Column: 5 Cols (Security Gate Telemetry & Analysis) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Security Gate Decision Card */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#ff4b4b]" />
                <span>Security Inspection Gate</span>
              </h3>
              <span className="text-[11px] font-mono text-slate-500">
                {scanResult ? `${scanResult.scanDurationMs} ms` : 'Ready'}
              </span>
            </div>

            {scanResult ? (
              <div className="space-y-3.5">
                {/* Risk Score Meter */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">Risk Severity Score:</span>
                    <span className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                      scanResult.riskScore > 60
                        ? 'bg-red-100 text-red-700'
                        : scanResult.riskScore > 25
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {scanResult.riskScore} / 100
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className={`h-2.5 rounded-full transition-all duration-500 ${
                        scanResult.riskScore > 60
                          ? 'bg-red-500'
                          : scanResult.riskScore > 25
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.max(5, scanResult.riskScore)}%` }}
                    />
                  </div>
                </div>

                {/* Gateway Action Pill */}
                <div className="p-2.5 rounded-md border text-xs flex items-center justify-between bg-slate-50 border-slate-200">
                  <span className="text-slate-600 font-medium">Gateway Decision:</span>
                  <span className={`font-bold px-2 py-0.5 rounded text-xs ${
                    scanResult.decision.action === 'BLOCK'
                      ? 'bg-red-600 text-white'
                      : scanResult.decision.action === 'SANITIZE_AND_SEND'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-blue-600 text-white'
                  }`}>
                    {scanResult.decision.action === 'BLOCK' ? '🛑 EGRESS BLOCKED' : scanResult.decision.action === 'SANITIZE_AND_SEND' ? '🛡️ SANITIZED & DISPATCHABLE' : '✅ ALLOWED (CLEAN)'}
                  </span>
                </div>

                {/* Intercepted Entities List */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">
                      Detected Entities ({scanResult.detectedEntities.length}):
                    </span>
                    <span className="text-[11px] text-slate-500">Categories</span>
                  </div>

                  {scanResult.detectedEntities.length === 0 ? (
                    <div className="p-3 rounded-md bg-emerald-50/70 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>No PII or secrets detected in this prompt.</span>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {scanResult.detectedEntities.map((entity) => (
                        <div
                          key={entity.id}
                          className="p-2.5 rounded-md border border-slate-200 bg-slate-50/70 text-xs space-y-1 hover:border-slate-300 transition-all"
                        >
                          <div className="flex items-center justify-between">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              entity.severity === 'critical'
                                ? 'bg-red-100 text-red-700 border border-red-200'
                                : entity.severity === 'high'
                                ? 'bg-orange-100 text-orange-700 border border-orange-200'
                                : 'bg-blue-100 text-blue-700 border border-blue-200'
                            }`}>
                              {entity.type}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500">
                              {Math.round(entity.confidence * 100)}% Conf
                            </span>
                          </div>

                          <div className="font-mono text-[11px] text-slate-800 truncate">
                            Value: <span className="font-semibold bg-white px-1 py-0.5 rounded border border-slate-200">{entity.value}</span>
                          </div>
                          <div className="text-[11px] text-slate-500 leading-tight">
                            {entity.suggestion}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-8 px-4 text-slate-500 space-y-2">
                <Shield className="w-8 h-8 mx-auto text-slate-300 stroke-1" />
                <p className="text-xs">Click <strong>"1. Scan & Protect"</strong> or <strong>"Scan, Protect & Send"</strong> to run the firewall inspection pipeline.</p>
              </div>
            )}
          </div>

          {/* Active Policy Rules Quick View */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs space-y-2.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <SettingsIcon className="w-3.5 h-3.5 text-slate-600" />
                <span>Active Egress Policy</span>
              </h4>
              <button
                onClick={() => onNavigate?.('settings')}
                className="text-[11px] font-semibold text-[#ff4b4b] hover:underline"
              >
                Configure
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
                <span className="text-slate-600">Email & Phone:</span>
                <span className="font-bold text-amber-700">{settings.policy.emailPhone}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
                <span className="text-slate-600">Govt IDs (PAN/Aadhaar/SSN):</span>
                <span className="font-bold text-red-700">{settings.policy.govtId}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
                <span className="text-slate-600">Credit Cards:</span>
                <span className="font-bold text-red-700">{settings.policy.creditCard}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
                <span className="text-slate-600">API Secrets:</span>
                <span className="font-bold text-red-700">{settings.policy.apiSecrets}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gemini Response Section */}
      {geminiResponse && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="p-4 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                  <span>Gemini Model Response</span>
                  <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-blue-500/20 text-blue-300 border border-blue-400/30">
                    {geminiResponse.model}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">Received from downstream LLM via secure AI Sentinel gateway</p>
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono text-slate-300">
              <span>Latency: <strong className="text-emerald-400">{geminiResponse.latencyMs} ms</strong></span>
              <span>•</span>
              <button
                id="btn-copy-gemini-response"
                onClick={() => copyToClipboard(geminiResponse.text, 'response')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-sans font-semibold transition-colors"
              >
                {copiedResponse ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedResponse ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div className="p-5 space-y-4">
            {geminiResponse.notice && (
              <div className="p-2.5 rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{geminiResponse.notice}</span>
                </div>
              </div>
            )}

            <div className="prose prose-slate max-w-none text-xs sm:text-sm text-slate-800 leading-relaxed font-sans whitespace-pre-wrap">
              {geminiResponse.text}
            </div>

            {/* Audit Log Confirmation Banner */}
            {lastAuditId && (
              <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-900 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Audit Record created in compliance log: <strong>{lastAuditId}</strong> (Original raw text was excluded from storage).</span>
                </div>
                <button
                  onClick={() => onNavigate?.('audit_logs')}
                  className="shrink-0 flex items-center gap-1 font-bold text-emerald-700 hover:text-emerald-900 underline"
                >
                  <span>View in Audit Logs</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
