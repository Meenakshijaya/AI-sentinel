import React from 'react';
import { ArrowUpRight, ArrowDownRight, HelpCircle } from 'lucide-react';

interface StreamlitMetricProps {
  id?: string;
  label: string;
  value: string;
  delta?: string;
  deltaType?: 'positive' | 'negative' | 'neutral';
  help?: string;
  isInverse?: boolean; // inverse color logic (e.g. increase in threats is red)
}

export const StreamlitMetric: React.FC<StreamlitMetricProps> = ({
  id,
  label,
  value,
  delta,
  deltaType = 'positive',
  help,
  isInverse = false
}) => {
  const isUp = delta && (delta.startsWith('+') || !delta.startsWith('-'));
  const isGood = isInverse ? !isUp : isUp;

  return (
    <div
      id={id}
      className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs flex flex-col justify-between transition-all hover:border-slate-300"
    >
      <div className="flex items-center justify-between gap-1 text-slate-500 text-xs font-medium mb-1.5">
        <span className="truncate">{label}</span>
        {help && (
          <span title={help} className="cursor-help text-slate-400 hover:text-slate-600">
            <HelpCircle className="w-3.5 h-3.5" />
          </span>
        )}
      </div>

      <div className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight my-0.5 font-mono">
        {value}
      </div>

      {delta && (
        <div className="flex items-center gap-1 mt-1">
          <span
            className={`inline-flex items-center gap-0.5 text-xs font-semibold px-1.5 py-0.5 rounded ${
              isGood
                ? 'bg-emerald-50 text-emerald-700'
                : 'bg-rose-50 text-rose-700'
            }`}
          >
            {isUp ? (
              <ArrowUpRight className="w-3 h-3 stroke-[2.5]" />
            ) : (
              <ArrowDownRight className="w-3 h-3 stroke-[2.5]" />
            )}
            {delta}
          </span>
        </div>
      )}
    </div>
  );
};
