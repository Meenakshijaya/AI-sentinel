import React, { useState } from 'react';
import { X, Copy, Check, Terminal, Play, Download } from 'lucide-react';
import { PYTHON_STREAMLIT_CODE } from '../data/mockData';

interface PythonCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonCodeModal: React.FC<PythonCodeModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(PYTHON_STREAMLIT_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([PYTHON_STREAMLIT_CODE], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'app.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/10 text-blue-600 flex items-center justify-center font-bold">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">app.py — Python & Streamlit Source Code</h3>
              <p className="text-xs text-slate-500">AI Sentinel Phase 1 Streamlit Architecture</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-download-app-py"
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-md transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download app.py</span>
            </button>
            <button
              id="btn-copy-app-py"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#ff4b4b] hover:bg-[#e03a3a] rounded-md transition-colors shadow-xs"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
            <button
              id="btn-close-python-modal"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Execution Instructions Banner */}
        <div className="px-5 py-2.5 bg-slate-900 text-slate-200 text-xs font-mono flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-emerald-400 font-bold">$</span>
            <span>streamlit run app.py</span>
          </div>
          <span className="text-slate-400 text-[11px]">Requires Python 3.9+ & streamlit</span>
        </div>

        {/* Code Content */}
        <div className="flex-1 p-4 overflow-y-auto bg-slate-950 font-mono text-xs text-slate-200 leading-relaxed">
          <pre className="whitespace-pre overflow-x-auto text-[12px] selection:bg-red-500/30">
            {PYTHON_STREAMLIT_CODE}
          </pre>
        </div>
      </div>
    </div>
  );
};
