import React from 'react';
import { Shield, Play, Terminal, CheckCircle2, Code2, Menu, X, ExternalLink } from 'lucide-react';

interface StreamlitHeaderProps {
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
  onViewPythonCode: () => void;
  currentPageName: string;
}

export const StreamlitHeader: React.FC<StreamlitHeaderProps> = ({
  sidebarOpen,
  onToggleSidebar,
  onViewPythonCode,
  currentPageName
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200">
      {/* Streamlit Iconic Top Accent Bar */}
      <div className="h-[3px] w-full bg-[#ff4b4b]" />
      
      <div className="flex items-center justify-between px-4 py-2.5">
        <div className="flex items-center gap-3">
          <button
            id="btn-toggle-sidebar"
            onClick={onToggleSidebar}
            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-700 transition-colors"
            title="Toggle Streamlit Sidebar"
            aria-label="Toggle Sidebar"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-[#ff4b4b]/10 text-[#ff4b4b] flex items-center justify-center font-bold">
              <Shield className="w-4 h-4" />
            </div>
            <span className="font-bold text-slate-900 tracking-tight text-base">AI Sentinel</span>
            <span className="hidden sm:inline-block text-xs font-medium px-2 py-0.5 rounded bg-red-50 text-[#ff4b4b] border border-red-200">
              Streamlit v1.38 • Phase 3 Active
            </span>
          </div>

          <span className="hidden md:inline-block text-slate-300">|</span>
          <span className="hidden md:inline-block text-xs font-semibold text-slate-600">
            {currentPageName}
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* Streamlit status pill */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="hidden sm:inline">Streamlit Runtime:</span> Active
          </div>

          <button
            id="btn-view-app-py"
            onClick={onViewPythonCode}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md border border-slate-300 transition-colors"
            title="View full Python Streamlit source code (app.py)"
          >
            <Code2 className="w-3.5 h-3.5 text-slate-700" />
            <span>app.py</span>
          </button>
        </div>
      </div>
    </header>
  );
};
