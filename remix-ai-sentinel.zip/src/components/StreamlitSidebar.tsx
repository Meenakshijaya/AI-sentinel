import React from 'react';
import { PageType } from '../types';
import { Home, ShieldCheck, BarChart3, FileText, Settings, ShieldAlert, Cpu, Sparkles, Terminal, Flame } from 'lucide-react';

interface StreamlitSidebarProps {
  currentPage: PageType;
  onSelectPage: (page: PageType) => void;
  isOpen: boolean;
}

interface NavItem {
  id: PageType;
  label: string;
  emoji: string;
  icon: React.ElementType;
  badge?: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', emoji: '🏠', icon: Home },
  { id: 'threat_simulator', label: 'Threat Simulator', emoji: '🔥', icon: Flame, badge: 'Phase 3' },
  { id: 'ai_playground', label: 'AI Playground', emoji: '✨', icon: Sparkles, badge: 'Live Gemini' },
  { id: 'pii_scanner', label: 'PII Scanner', emoji: '🔍', icon: ShieldCheck, badge: 'Live' },
  { id: 'security_dashboard', label: 'Security Dashboard', emoji: '📊', icon: BarChart3 },
  { id: 'audit_logs', label: 'Audit Logs', emoji: '📜', icon: FileText },
  { id: 'settings', label: 'Settings', emoji: '⚙️', icon: Settings },
];

export const StreamlitSidebar: React.FC<StreamlitSidebarProps> = ({
  currentPage,
  onSelectPage,
  isOpen
}) => {
  if (!isOpen) return null;

  return (
    <aside className="w-72 sm:w-80 shrink-0 bg-[#f8fafc] border-r border-slate-200 flex flex-col h-[calc(100vh-48px)] overflow-y-auto font-sans">
      {/* Streamlit Sidebar Header */}
      <div className="p-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 text-white flex items-center justify-center shadow-sm">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 leading-tight">AI Sentinel</h2>
            <p className="text-xs text-slate-500 font-medium">Streamlit Security Gateway</p>
          </div>
        </div>
      </div>

      {/* Streamlit st.sidebar.radio */}
      <div className="px-4 py-3 flex-1">
        <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 px-2 block mb-2">
          Navigation Menu
        </label>
        <nav className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const isSelected = currentPage === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                onClick={() => onSelectPage(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isSelected
                    ? 'bg-[#ff4b4b] text-white shadow-sm font-semibold'
                    : 'text-slate-700 hover:bg-slate-200/70 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-base">{item.emoji}</span>
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[11px] px-2 py-0.5 rounded font-medium ${
                      isSelected
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Streamlit Divider */}
        <div className="my-5 border-t border-slate-200" />

        {/* st.sidebar.info widget */}
        <div className="rounded-lg bg-blue-50 border border-blue-200 p-3.5 text-xs text-blue-900 space-y-2">
          <div className="flex items-center gap-2 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>DLP Guard: ACTIVE</span>
          </div>
          <p className="text-blue-800 text-[11px] leading-relaxed">
            Real-time proxy inspection enabled for SSN, PCI cards, tokens, and PHI before model dispatch.
          </p>
        </div>

        {/* Engine Telemetry Card */}
        <div className="mt-4 p-3 rounded-lg bg-white border border-slate-200 shadow-xs space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-slate-500 font-medium">
            <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5" /> Engine</span>
            <span className="text-slate-800 font-semibold">Hybrid Regex + AI</span>
          </div>
          <div className="flex items-center justify-between text-slate-500 font-medium">
            <span className="flex items-center gap-1.5"><Terminal className="w-3.5 h-3.5" /> Latency</span>
            <span className="text-emerald-600 font-semibold">~12.4 ms</span>
          </div>
          <div className="flex items-center justify-between text-slate-500 font-medium">
            <span className="flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5" /> Gateway</span>
            <span className="text-[#ff4b4b] font-semibold">Phase 2 Active</span>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-4 border-t border-slate-200 text-[11px] text-slate-500 text-center">
        <span>AI Sentinel • Hackathon Edition</span>
      </div>
    </aside>
  );
};
