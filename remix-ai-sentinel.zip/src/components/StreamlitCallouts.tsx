import React from 'react';
import { Info, CheckCircle2, AlertTriangle, AlertCircle } from 'lucide-react';

interface CalloutProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
}

export const StInfo: React.FC<CalloutProps> = ({ children, title, className = '' }) => (
  <div className={`p-3.5 rounded-md bg-blue-50 border-l-4 border-blue-500 text-blue-900 text-sm flex gap-3 ${className}`}>
    <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
    <div className="flex-1">
      {title && <div className="font-semibold text-blue-950 mb-0.5">{title}</div>}
      <div className="text-blue-800 leading-relaxed">{children}</div>
    </div>
  </div>
);

export const StSuccess: React.FC<CalloutProps> = ({ children, title, className = '' }) => (
  <div className={`p-3.5 rounded-md bg-emerald-50 border-l-4 border-emerald-500 text-emerald-900 text-sm flex gap-3 ${className}`}>
    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
    <div className="flex-1">
      {title && <div className="font-semibold text-emerald-950 mb-0.5">{title}</div>}
      <div className="text-emerald-800 leading-relaxed">{children}</div>
    </div>
  </div>
);

export const StWarning: React.FC<CalloutProps> = ({ children, title, className = '' }) => (
  <div className={`p-3.5 rounded-md bg-amber-50 border-l-4 border-amber-500 text-amber-900 text-sm flex gap-3 ${className}`}>
    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
    <div className="flex-1">
      {title && <div className="font-semibold text-amber-950 mb-0.5">{title}</div>}
      <div className="text-amber-800 leading-relaxed">{children}</div>
    </div>
  </div>
);

export const StError: React.FC<CalloutProps> = ({ children, title, className = '' }) => (
  <div className={`p-3.5 rounded-md bg-rose-50 border-l-4 border-rose-500 text-rose-900 text-sm flex gap-3 ${className}`}>
    <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
    <div className="flex-1">
      {title && <div className="font-semibold text-rose-950 mb-0.5">{title}</div>}
      <div className="text-rose-800 leading-relaxed">{children}</div>
    </div>
  </div>
);
