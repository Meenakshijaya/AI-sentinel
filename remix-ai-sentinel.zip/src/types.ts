export type PageType = 'home' | 'threat_simulator' | 'ai_playground' | 'pii_scanner' | 'security_dashboard' | 'audit_logs' | 'settings';

export type PIIEntityType = 
  | 'EMAIL' 
  | 'PHONE' 
  | 'SSN' 
  | 'CREDIT_CARD' 
  | 'API_KEY' 
  | 'IP_ADDRESS' 
  | 'NAME' 
  | 'MEDICAL_ID'
  | 'PAN'
  | 'AADHAAR'
  | 'PROMPT_INJECTION'
  | 'BANK_ACCOUNT';

export interface PIIEntity {
  id: string;
  type: PIIEntityType;
  value: string;
  confidence: number;
  startIndex: number;
  endIndex: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  suggestion: string;
}

export type ThreatCategory = 
  | 'PII_EXPOSURE'
  | 'FINANCIAL_DATA_EXPOSURE'
  | 'GOVERNMENT_ID_EXPOSURE'
  | 'CREDENTIAL_SECRET_EXPOSURE'
  | 'HEALTHCARE_DATA_EXPOSURE'
  | 'PROMPT_INJECTION'
  | 'MULTIPLE_THREATS'
  | 'SAFE_NORMAL';

export interface ThreatClassification {
  primaryCategory: ThreatCategory;
  categoryLabel: string;
  detectedThreats: string[];
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  riskScore: number;
  hasPromptInjection: boolean;
  explanation: string;
}

export interface GateDecision {
  action: 'ALLOW' | 'SANITIZE_AND_SEND' | 'BLOCK';
  reason: string;
  blockedCategories: string[];
  maskedCategories: string[];
  whyExplanation?: {
    threat: string;
    risk: string;
    detected: string[];
    policy: 'ALLOW' | 'MASK' | 'REDACT' | 'BLOCK';
    reason: string;
  };
}

export interface ScanResult {
  originalText: string;
  redactedText: string;
  detectedEntities: PIIEntity[];
  riskScore: number; // 0 to 100
  threatClassification: ThreatClassification;
  scanDurationMs: number;
  timestamp: string;
  decision: GateDecision;
}

export interface SecurityMetric {
  title: string;
  value: string;
  delta: string;
  deltaType: 'positive' | 'negative' | 'neutral';
  help?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  eventType: 'PII_INTERCEPTED' | 'PROMPT_INJECTION' | 'POLICY_VIOLATION' | 'API_KEY_LEAK' | 'AUTHENTICATION' | 'CONFIG_CHANGE' | 'SECURE_LLM_DISPATCH' | 'THREAT_SIMULATION_BLOCKED' | 'THREAT_SIMULATION_SANITIZED';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  sourceApp: string;
  userId: string;
  ipAddress: string;
  details: string;
  status: 'BLOCKED' | 'QUARANTINED' | 'FLAGGED' | 'RESOLVED' | 'SANITIZED';
  latencyMs: number;
  detectedCategories?: string[];
  riskScore?: number;
  policyAction?: 'ALLOW' | 'SANITIZE_AND_SEND' | 'BLOCK';
}

export interface PolicySettings {
  emailPhone: 'MASK' | 'BLOCK' | 'ALLOW';
  govtId: 'BLOCK' | 'REDACT' | 'ALLOW';
  creditCard: 'BLOCK' | 'REDACT' | 'ALLOW';
  apiSecrets: 'BLOCK' | 'REDACT' | 'ALLOW';
  healthRecords: 'BLOCK' | 'REDACT' | 'ALLOW';
  promptInjection: 'BLOCK' | 'REDACT' | 'ALLOW';
  names: 'MASK' | 'ALLOW';
  ipAddresses: 'MASK' | 'ALLOW';
  maxRiskScoreBeforeBlock: number; // e.g. 80
  defaultAction: 'ALLOW';
}

export interface SentinelSettings {
  detectors: {
    ssn: boolean;
    pan: boolean;
    aadhaar: boolean;
    creditCard: boolean;
    emailPhone: boolean;
    apiKeys: boolean;
    names: boolean;
    passwords: boolean;
    healthRecords: boolean;
    ipAddresses: boolean;
    promptInjection: boolean;
    customRegex: boolean;
  };
  policy: PolicySettings;
  customRegexPattern: string;
  confidenceThreshold: number; // 0.0 to 1.0
  redactionStyle: 'MASK_CHAR' | 'ENTITY_TAG' | 'HASH' | 'BLUR';
  maskChar: string;
  blockOnCritical: boolean;
  notifySlack: boolean;
  slackWebhookUrl: string;
  environment: 'development' | 'staging' | 'production';
  aiModerationLevel: 'lax' | 'standard' | 'strict';
}

export interface GeminiGatewayResponse {
  text: string;
  model: string;
  mode: 'live' | 'simulation';
  latencyMs: number;
  tokenCount?: number;
  notice?: string;
  timestamp?: string;
}

export interface AttackScenario {
  id: string;
  code: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  name: string;
  category: ThreatCategory;
  categoryLabel: string;
  description: string;
  prompt: string;
  expectedThreats: string[];
  severityLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  iconEmoji: string;
  targetObjective: string;
}

export interface AttackHistoryRecord {
  id: string;
  timestamp: string;
  attackType: string;
  riskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  detectedData: string[];
  decision: 'ALLOW' | 'MASK' | 'REDACT' | 'BLOCK';
  status: 'BLOCKED' | 'SANITIZED' | 'ALLOWED';
  latencyMs: number;
  summary: string;
}

export interface ThreatSimulatorScorecard {
  attacksSimulated: number;
  threatsDetected: number;
  threatsBlocked: number;
  threatsSanitized: number;
  averageRiskScore: number;
  sensitiveEntitiesDetected: number;
}


