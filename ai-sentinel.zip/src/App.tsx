import React, { useState } from 'react';
import { PageType, SentinelSettings, AuditLogEntry } from './types';
import { INITIAL_SETTINGS, MOCK_AUDIT_LOGS } from './data/mockData';
import { StreamlitHeader } from './components/StreamlitHeader';
import { StreamlitSidebar } from './components/StreamlitSidebar';
import { PythonCodeModal } from './components/PythonCodeModal';
import { HomePage } from './pages/HomePage';
import { ThreatSimulatorPage } from './pages/ThreatSimulatorPage';
import { AIPlaygroundPage } from './pages/AIPlaygroundPage';
import { PIIScannerPage } from './pages/PIIScannerPage';
import { SecurityDashboardPage } from './pages/SecurityDashboardPage';
import { AuditLogsPage } from './pages/AuditLogsPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(true);
  const [isPythonModalOpen, setIsPythonModalOpen] = useState<boolean>(false);
  const [settings, setSettings] = useState<SentinelSettings>(INITIAL_SETTINGS);
  const [logs, setLogs] = useState<AuditLogEntry[]>(MOCK_AUDIT_LOGS);

  const handleAddAuditLog = (entry: AuditLogEntry) => {
    setLogs((prev) => [entry, ...prev]);
  };

  const getPageTitle = (page: PageType) => {
    switch (page) {
      case 'home':
        return '🏠 Home';
      case 'threat_simulator':
        return '🔥 AI Threat Simulator';
      case 'ai_playground':
        return '✨ AI Playground (Gemini Gateway)';
      case 'pii_scanner':
        return '🔍 PII Scanner';
      case 'security_dashboard':
        return '📊 Security Dashboard';
      case 'audit_logs':
        return '📜 Audit Logs';
      case 'settings':
        return '⚙️ Settings';
      case 'about':
        return 'ℹ️ About AI Sentinel';
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col font-sans selection:bg-[#ff4b4b]/20 selection:text-[#ff4b4b]">
      {/* Top Streamlit Header */}
      <StreamlitHeader
        sidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        onViewPythonCode={() => setIsPythonModalOpen(true)}
        currentPageName={getPageTitle(currentPage)}
      />

      {/* Main Streamlit Split Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <StreamlitSidebar
          currentPage={currentPage}
          onSelectPage={(page) => setCurrentPage(page)}
          isOpen={sidebarOpen}
        />

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-between">
          <div className="flex-1">
            {currentPage === 'home' && (
              <HomePage
                onNavigate={(page) => setCurrentPage(page)}
                onOpenPythonCode={() => setIsPythonModalOpen(true)}
              />
            )}

            {currentPage === 'threat_simulator' && (
              <ThreatSimulatorPage
                settings={settings}
                onNavigate={(page) => setCurrentPage(page)}
                onAddAuditLog={handleAddAuditLog}
              />
            )}

            {currentPage === 'ai_playground' && (
              <AIPlaygroundPage
                settings={settings}
                onNavigate={(page) => setCurrentPage(page)}
                onAddAuditLog={handleAddAuditLog}
              />
            )}

            {currentPage === 'pii_scanner' && (
              <PIIScannerPage
                settings={settings}
                onUpdateSettings={(newSettings) => setSettings(newSettings)}
              />
            )}

            {currentPage === 'security_dashboard' && (
              <SecurityDashboardPage />
            )}

            {currentPage === 'audit_logs' && (
              <AuditLogsPage logs={logs} />
            )}

            {currentPage === 'settings' && (
              <SettingsPage
                settings={settings}
                onUpdateSettings={(newSettings) => setSettings(newSettings)}
                onOpenPythonCode={() => setIsPythonModalOpen(true)}
              />
            )}

            {currentPage === 'about' && (
              <AboutPage
                onNavigate={(page) => setCurrentPage(page)}
              />
            )}
          </div>

          {/* Global Footer on every page */}
          <footer className="mt-10 py-4 px-6 border-t border-slate-200/90 text-center text-xs font-semibold text-slate-600 bg-white/70 backdrop-blur-xs rounded-xl shadow-2xs">
            AI Sentinel | Team Code Cosmos | Team Lead Meenakshi S.
          </footer>
        </main>
      </div>

      {/* Python Code Viewer Modal */}
      <PythonCodeModal
        isOpen={isPythonModalOpen}
        onClose={() => setIsPythonModalOpen(false)}
      />
    </div>
  );
}
