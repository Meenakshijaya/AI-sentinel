import React from 'react';
import { 
  ShieldCheck, 
  Users, 
  UserCheck, 
  Sparkles, 
  CheckCircle2, 
  Flame, 
  ArrowRight, 
  Lock
} from 'lucide-react';
import { PageType } from '../types';

interface AboutPageProps {
  onNavigate?: (page: PageType) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12 font-sans">
      {/* Hero Banner with Professional Security Icon */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 right-1/3 w-64 h-64 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 border border-red-400/30 text-red-300 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
              <span>Zero-Trust AI Security Gateway</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white flex items-center gap-3">
              <span>About AI Sentinel</span>
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              <strong>AI Sentinel</strong> is an intelligent reverse-proxy security gateway and Data Loss Prevention (DLP) guardian designed to intercept, analyze, sanitize, and audit sensitive data before prompts reach upstream Generative AI models.
            </p>
          </div>

          {/* Professional Security Icon Showcase */}
          <div className="shrink-0 flex items-center justify-center">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-gradient-to-br from-red-500 via-rose-600 to-indigo-600 p-0.5 shadow-2xl shadow-red-500/20 group hover:scale-105 transition-transform duration-300">
              <div className="w-full h-full rounded-2xl bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-red-500/10 animate-pulse"></div>
                <ShieldCheck className="w-12 h-12 text-[#ff4b4b] relative z-10" />
                <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mt-1 relative z-10">
                  SECURE AI
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Team Profile & Attribution Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Team Card */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs hover:shadow-md hover:border-slate-300 transition-all space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-red-50 text-[#ff4b4b] flex items-center justify-center font-bold shadow-xs">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-[#ff4b4b] uppercase tracking-wider">Project Team</span>
              <h2 className="text-xl font-extrabold text-slate-900">Code Cosmos</h2>
            </div>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Team <strong>Code Cosmos</strong> is dedicated to crafting resilient, zero-trust engineering systems that empower enterprise AI adoption safely, adhering strictly to global data protection laws and cybersecurity best practices.
          </p>
          <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium">AI Safety</span>
            <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium">DLP Engineering</span>
            <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium">Prompt Guardrails</span>
          </div>
        </div>

        {/* Team Lead Card */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs hover:shadow-md hover:border-slate-300 transition-all space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shadow-xs">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Leadership</span>
              <h2 className="text-xl font-extrabold text-slate-900">Meenakshi S</h2>
              <span className="text-xs text-slate-500 font-medium">Team Lead & Systems Architect</span>
            </div>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Leading the architectural design, security compliance heuristics, and end-to-end integration of AI Sentinel's zero-trust proxy and threat simulation engine.
          </p>
          <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 font-medium">Zero-Trust Architecture</span>
            <span className="px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 font-medium">System Direction</span>
          </div>
        </div>
      </div>

      {/* Core Mission & Value Pillars */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-[#ff4b4b]" />
            <span>Mission & Architectural Pillars</span>
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Built with modern security principles to prevent data exfiltration, regulatory penalties, and model prompt hijacking.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Pillar 1 */}
          <div className="p-5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors space-y-2.5">
            <div className="w-9 h-9 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Zero-Trust Egress</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every prompt payload is treated as untrusted. Sensitive statutory IDs (Indian PAN, Aadhaar), credit cards, and API secrets are caught before egress.
            </p>
          </div>

          {/* Pillar 2 */}
          <div className="p-5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors space-y-2.5">
            <div className="w-9 h-9 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
              <Flame className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Threat Simulation Lab</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Red-team ready testing suite with 6 ready-made adversarial scenarios and 1-click test triggers for rapid security assessment.
            </p>
          </div>

          {/* Pillar 3 */}
          <div className="p-5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors space-y-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm">Tamper-Evident Auditing</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Comprehensive telemetry, risk scoring (0-100), and compliance-ready audit logs with CSV/JSON exports for SOC2, HIPAA, and ISO 27001.
            </p>
          </div>
        </div>

        {/* Quick Launch CTA */}
        <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-500">
            AI Sentinel • Powered by Google Gemini 3.7 Flash & Streamlit Architecture.
          </div>
          <div className="flex gap-2.5">
            {onNavigate && (
              <>
                <button
                  onClick={() => onNavigate('threat_simulator')}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>Launch Threat Simulator</span>
                </button>
                <button
                  onClick={() => onNavigate('security_dashboard')}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg border border-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>View Security Dashboard</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
