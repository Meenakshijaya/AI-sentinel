import React, { useState } from 'react';
import { AuditLogEntry } from '../types';
import { FileText, Search, Download, Filter, ShieldAlert, Eye, X, CheckCircle2, AlertOctagon, Terminal, Sparkles, Bot } from 'lucide-react';

interface AuditLogsPageProps {
  logs: AuditLogEntry[];
}

export const AuditLogsPage: React.FC<AuditLogsPageProps> = ({ logs }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEventType, setSelectedEventType] = useState<string>('ALL');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [inspectedLog, setInspectedLog] = useState<AuditLogEntry | null>(null);

  // Filter logic
  const filteredLogs = logs.filter((log) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      searchQuery === '' ||
      (log.id || '').toLowerCase().includes(q) ||
      (log.sourceApp || '').toLowerCase().includes(q) ||
      (log.userId || '').toLowerCase().includes(q) ||
      (log.details || '').toLowerCase().includes(q) ||
      (log.ipAddress || '').includes(searchQuery);

    const matchesType = selectedEventType === 'ALL' || log.eventType === selectedEventType;
    const matchesSeverity = selectedSeverity === 'ALL' || log.severity === selectedSeverity;

    return matchesSearch && matchesType && matchesSeverity;
  });

  const handleExportCSV = () => {
    const headers = ['Log ID', 'Timestamp', 'Event Type', 'Severity', 'Source App', 'User ID', 'IP Address', 'Status', 'Details', 'Latency (ms)'];
    const rows = filteredLogs.map(l => [
      l.id || '',
      l.timestamp || '',
      l.eventType || '',
      l.severity || '',
      `"${(l.sourceApp || '').replace(/"/g, '""')}"`,
      l.userId || '',
      l.ipAddress || '',
      l.status || '',
      `"${(l.details || '').replace(/"/g, '""')}"`,
      l.latencyMs ?? 0
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `sentinel_audit_logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportJSON = () => {
    const jsonContent = JSON.stringify(filteredLogs, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `sentinel_audit_logs_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getSeverityStyle = (sev: AuditLogEntry['severity']) => {
    switch (sev) {
      case 'CRITICAL':
        return 'bg-red-100 text-red-700 border-red-200 font-bold';
      case 'HIGH':
        return 'bg-amber-100 text-amber-800 border-amber-200 font-semibold';
      case 'MEDIUM':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  const getDataTypeBadgeClass = (category: string) => {
    const cat = category.toUpperCase();
    if (cat.includes('API') || cat.includes('SECRET') || cat.includes('TOKEN')) {
      return 'bg-purple-100 text-purple-700 border-purple-200 font-bold';
    }
    if (cat.includes('AADHAAR') || cat.includes('PAN') || cat.includes('SSN') || cat.includes('GOVT')) {
      return 'bg-rose-100 text-rose-700 border-rose-200 font-bold';
    }
    if (cat.includes('CREDIT') || cat.includes('CARD') || cat.includes('FINANCIAL')) {
      return 'bg-red-100 text-red-700 border-red-200 font-bold';
    }
    if (cat.includes('EMAIL') || cat.includes('PHONE') || cat.includes('NAME') || cat.includes('CONTACT')) {
      return 'bg-blue-100 text-blue-700 border-blue-200 font-medium';
    }
    if (cat.includes('PROMPT') || cat.includes('INJECTION') || cat.includes('JAILBREAK')) {
      return 'bg-orange-100 text-orange-800 border-orange-200 font-bold';
    }
    if (cat.includes('HEALTH') || cat.includes('HIPAA')) {
      return 'bg-teal-100 text-teal-800 border-teal-200 font-semibold';
    }
    return 'bg-slate-100 text-slate-700 border-slate-200 font-medium';
  };

  const getActionBadgeStyle = (action?: string, status?: string) => {
    const act = (action || (status === 'BLOCKED' ? 'BLOCK' : status === 'SANITIZED' ? 'SANITIZE' : 'ALLOW')).toUpperCase();
    if (act.includes('BLOCK')) {
      return 'bg-red-600 text-white border-red-700 font-bold shadow-2xs';
    }
    if (act.includes('SANITIZE') || act.includes('MASK') || act.includes('REDACT')) {
      return 'bg-blue-100 text-blue-800 border-blue-200 font-semibold';
    }
    if (act.includes('QUARANTINE')) {
      return 'bg-purple-100 text-purple-800 border-purple-200 font-semibold';
    }
    if (act.includes('FLAG')) {
      return 'bg-amber-100 text-amber-800 border-amber-200 font-semibold';
    }
    return 'bg-emerald-100 text-emerald-800 border-emerald-200 font-semibold';
  };

  const getDetectedDataTypes = (log: AuditLogEntry): string[] => {
    if (log.detectedCategories && log.detectedCategories.length > 0) {
      return log.detectedCategories;
    }
    const det = log.details || '';
    const types: string[] = [];
    if (det.includes('Aadhaar')) types.push('AADHAAR');
    if (det.includes('PAN')) types.push('PAN_CARD');
    if (det.includes('Credit Card') || det.includes('Card')) types.push('CREDIT_CARD');
    if (det.includes('API') || det.includes('Key') || det.includes('Token')) types.push('API_KEY');
    if (det.includes('Email')) types.push('EMAIL');
    if (det.includes('Phone')) types.push('PHONE');
    if (det.includes('SSN')) types.push('SSN');
    if (det.includes('Injection') || det.includes('Jailbreak')) types.push('PROMPT_INJECTION');
    if (det.includes('Name')) types.push('NAME');
    if (types.length === 0) {
      if (log.eventType.includes('INJECTION')) return ['PROMPT_INJECTION'];
      if (log.eventType.includes('BLOCKED')) return ['HIGH_RISK_PII'];
      return ['CLEAN'];
    }
    return types;
  };

  const getActionTaken = (log: AuditLogEntry): string => {
    if (log.policyAction) return log.policyAction;
    if (log.status === 'BLOCKED' || log.eventType.includes('BLOCK')) return 'BLOCK';
    if (log.status === 'SANITIZED' || log.eventType.includes('SANITIZ') || log.eventType.includes('REDACT')) return 'SANITIZE_AND_SEND';
    if (log.status === 'QUARANTINED') return 'QUARANTINE';
    if (log.status === 'FLAGGED') return 'FLAG';
    return 'ALLOW';
  };

  const getStatusStyle = (status: AuditLogEntry['status']) => {
    switch (status) {
      case 'BLOCKED':
        return 'bg-rose-100 text-rose-800 border-rose-200 font-bold';
      case 'QUARANTINED':
        return 'bg-purple-100 text-purple-800 border-purple-200 font-semibold';
      case 'FLAGGED':
        return 'bg-amber-100 text-amber-800 border-amber-200 font-semibold';
      case 'SANITIZED':
        return 'bg-sky-100 text-sky-800 border-sky-200 font-semibold';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200 font-semibold';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Title */}
      <div className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <span>📜</span>
            <span>Compliance & Security Audit Logs</span>
          </h1>
          <p className="text-slate-600 text-sm mt-1.5">
            Tamper-evident logs of all intercepted payloads, policy violations, and protected Gemini dispatches (excluding raw sensitive text).
          </p>
        </div>

        {/* Compliance Badges */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
            SOC2 Ready
          </span>
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
            HIPAA Audit
          </span>
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
            Zero Raw Secrets Stored
          </span>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          {/* Search Box */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              id="input-search-logs"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by log ID, user, source app, or IP..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 text-slate-800 text-xs sm:text-sm rounded-md focus:ring-2 focus:ring-[#ff4b4b] focus:border-transparent outline-none"
            />
          </div>

          {/* Event Type Filter */}
          <div className="sm:col-span-3">
            <select
              id="select-filter-event-type"
              value={selectedEventType}
              onChange={(e) => setSelectedEventType(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-700 text-xs sm:text-sm rounded-md px-3 py-2 focus:ring-2 focus:ring-[#ff4b4b] outline-none"
            >
              <option value="ALL">All Event Types</option>
              <option value="SECURE_LLM_DISPATCH">Secure Gemini Dispatch</option>
              <option value="PII_INTERCEPTED">PII Intercepted</option>
              <option value="API_KEY_LEAK">API Key Leak</option>
              <option value="PROMPT_INJECTION">Prompt Injection</option>
              <option value="POLICY_VIOLATION">Policy Violation</option>
              <option value="CONFIG_CHANGE">Config Change</option>
              <option value="AUTHENTICATION">Authentication</option>
            </select>
          </div>

          {/* Severity Filter */}
          <div className="sm:col-span-3">
            <select
              id="select-filter-severity"
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-700 text-xs sm:text-sm rounded-md px-3 py-2 focus:ring-2 focus:ring-[#ff4b4b] outline-none"
            >
              <option value="ALL">All Severities</option>
              <option value="CRITICAL">Critical</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>
          </div>
        </div>

        {/* Action bar */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500">
          <span>Showing {filteredLogs.length} of {logs.length} audit records</span>

          <div className="flex items-center gap-2">
            <button
              id="btn-export-csv"
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-md border border-slate-300 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              id="btn-export-json"
              onClick={handleExportJSON}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-md border border-slate-300 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
          </div>
        </div>
      </div>

      {/* Streamlit st.dataframe Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 uppercase font-semibold text-[11px] tracking-wider">
                <th className="py-3 px-3.5">Log ID</th>
                <th className="py-3 px-3">Timestamp</th>
                <th className="py-3 px-3">Risk Level</th>
                <th className="py-3 px-3">Detected Data Type</th>
                <th className="py-3 px-3">Action Taken</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Source & User</th>
                <th className="py-3 px-3 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-sans">
                    No matching audit records found. Try adjusting your filters.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr
                    key={log.id}
                    onClick={() => setInspectedLog(log)}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-3.5 font-bold text-slate-900 font-sans">
                      <span className="hover:text-red-600 transition-colors">{log.id}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 whitespace-nowrap font-mono text-[11px]">
                      {log.timestamp}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[10px] uppercase font-bold tracking-wide ${getSeverityStyle(log.severity)}`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                        <span>{log.severity}</span>
                        {log.riskScore !== undefined && (
                          <span className="opacity-75">({log.riskScore})</span>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex flex-wrap gap-1 max-w-[210px]">
                        {getDetectedDataTypes(log).map((cat, idx) => (
                          <span
                            key={idx}
                            className={`px-2 py-0.5 rounded-md border text-[10px] shadow-2xs whitespace-nowrap ${getDataTypeBadgeClass(cat)}`}
                          >
                            {cat}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md border text-[10px] font-bold tracking-wide shadow-2xs ${getActionBadgeStyle(getActionTaken(log), log.status)}`}>
                        {getActionTaken(log)}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full border text-[10px] font-bold tracking-wide shadow-2xs ${getStatusStyle(log.status)}`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-sans text-slate-700 text-[11px]">
                      <div className="font-semibold text-slate-900">{log.sourceApp}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{log.userId}</div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectedLog(log);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                        title="View Forensic Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Forensic Inspection Modal */}
      {inspectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#ff4b4b]" />
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">Security Incident Forensics: {inspectedLog.id}</h3>
                  <span className="text-xs text-slate-500">{inspectedLog.timestamp}</span>
                </div>
              </div>

              <button
                onClick={() => setInspectedLog(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs font-sans">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-500 block uppercase text-[10px] font-semibold">Event Type</span>
                  <span className="font-bold text-slate-900">{inspectedLog.eventType}</span>
                </div>
                <div>
                  <span className="text-slate-500 block uppercase text-[10px] font-semibold">Severity</span>
                  <span className={`px-2 py-0.5 rounded border text-[10px] font-bold ${getSeverityStyle(inspectedLog.severity)}`}>
                    {inspectedLog.severity}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block uppercase text-[10px] font-semibold">Gateway Action</span>
                  <span className={`px-2 py-0.5 rounded border text-[10px] font-semibold ${getStatusStyle(inspectedLog.status)}`}>
                    {inspectedLog.status}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block uppercase text-[10px] font-semibold">Gateway Overhead</span>
                  <span className="font-bold text-emerald-600 font-mono">{inspectedLog.latencyMs} ms</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="font-bold text-slate-700 uppercase tracking-wide text-[11px]">Source & Network Identity:</span>
                <div className="p-3 bg-slate-100 rounded border border-slate-200 font-mono text-[11px] text-slate-800 space-y-1">
                  <div>Source Application: <span className="font-bold">{inspectedLog.sourceApp}</span></div>
                  <div>User Identifier: <span className="font-bold">{inspectedLog.userId}</span></div>
                  <div>Origin IP Address: <span className="font-bold">{inspectedLog.ipAddress}</span></div>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="font-bold text-slate-700 uppercase tracking-wide text-[11px]">Sanitization & Security Payload:</span>
                <div className="p-3 bg-slate-950 text-slate-100 rounded border border-slate-800 font-mono text-[11px] leading-relaxed">
                  {inspectedLog.details}
                </div>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setInspectedLog(null)}
                className="px-4 py-1.5 bg-slate-900 text-white rounded-md text-xs font-semibold hover:bg-slate-800"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
